local shared_package_init = include("../Fancar/character.lua")

function package_init(character)
    local character_info = {
        name = "Fancar",
        hp = 100,
        damage = 80,
        damage_tatsumaki = 80,
        idle_frames_min = 160, --200,212,180,178,173,164,209,172,161,206,166 ???
        idle_frames_max = 220,
        move_tiles = 3
    }
    if character:get_rank() == Rank.V2 then
        character_info.hp = 140
        character_info.damage = 120
        character_info.damage_tatsumaki = 120
        character_info.idle_frames_min = 150 --210,173,163,207,168,151,184,186,190,197,212 ???
        character_info.idle_frames_max = 220
        character_info.move_tiles = 5
    elseif character:get_rank() == Rank.V3 then
        character_info.hp = 180
        character_info.damage = 160
        character_info.damage_tatsumaki = 160
        character_info.idle_frames_min = 70 --85,130,95,88,73 ???
        character_info.idle_frames_max = 130
    end
    shared_package_init(character,character_info)
end