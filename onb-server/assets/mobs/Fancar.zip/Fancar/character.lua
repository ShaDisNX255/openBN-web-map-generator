local debug = false

local AUDIO_DAMAGE = Engine.load_audio(_folderpath.."sfx/EXE1_26.ogg")

local CHARACTER_TEXTURE = Engine.load_texture(_folderpath.."gfx/battle.grayscaled.png")
local CHARACTER_ANIMATION = _folderpath.."gfx/battle.animation"

local TATSUMAKI_TEXTURE = Engine.load_texture(_folderpath.."gfx/tatsumaki.grayscaled.png")
local TATSUMAKI_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/tatsumaki.png")
local TATSUMAKI_ANIMPATH = _folderpath.."gfx/tatsumaki.animation"
local TATSUMAKI_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE1_12.ogg")

local EFFECT_TEXTURE = Engine.load_texture(_folderpath.."gfx/effect.grayscaled.png") -- flip for Player 2?
local EFFECT_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/effect.png")
local EFFECT_ANIMPATH = _folderpath.."gfx/effect.animation"

--possible states for character
local states = { IDLE = 1, ATTACK = 2}

function debug_print(str)
    if debug then
        print("[Fancar] "..str)
    end
end

--(Function by Alrysc)
local function graphic_init(type, x, y, texture, palette, animation, layer, state, anim_playback, user, facing, delete_on_complete, relative_to_user, flip)
    texture = texture or nil
    animation = animation or nil
    layer = layer or nil
    state = state or nil
    anim_playback = anim_playback or nil
    facing = facing or nil
    delete_on_complete = delete_on_complete or false
    flip = flip or false
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(user:get_team())
    end
    if palette then
        graphic:store_base_palette(palette)
        graphic:set_palette(graphic:get_base_palette())
    end
    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then 
        graphic:set_facing(facing)
    end
    
    if relative_to_user and user:get_facing() == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end

local function create_tatsumaki(user, tile, move_tiles)
	local user = user
	local saved_direction = user:get_facing()
    local spawn_next
    spawn_next = function()
        if not tile or tile:is_edge() or move_tiles <= 0 then return end
        local tatsumaki = graphic_init("spell", 0, 0, TATSUMAKI_TEXTURE, TATSUMAKI_PALETTE, TATSUMAKI_ANIMPATH, -3, "0", Playback.Loop, user, saved_direction, false, true)
        tatsumaki:set_hit_props(
            HitProps.new(
                user.damage_tatsumaki,
                Hit.Impact | Hit.Flinch | Hit.Flash,
                Element.None,
                user:get_context(),
                Drag.None
            )
        )
        tatsumaki.frames = 0
	    local target = nil
	    local direction = nil
        tatsumaki.on_spawn_func = function(self)
	    	Engine.play_audio(TATSUMAKI_AUDIO, AudioPriority.Low)
        end
        tatsumaki.update_func = function(self)
            self.frames = self.frames + 1
            self:get_tile():attack_entities(self)
            self:highlight_tile(Highlight.Solid)
            if self.frames == 41-1 then
                move_tiles = move_tiles - 1
		        -- Find target if we don't have one
		        if not target then
		        	local closest_dist = math.huge
		        	self:get_field():find_characters(function(character)
		        		local character_team = character:get_team()
		        		if (
		        			character_team == user:get_team() or
		        			character_team == Team.Other or
		        			character:will_erase_eof()
		        		) then
		        			return false
		        		end
		        		if not target then
		        			target = character
		        		else
		        			-- If the distance to one enemy is shorter than the other, target the shortest enemy path
		        			local dist = math.abs(tile:x() - character:get_tile():x()) + math.abs(tile:y() - character:get_tile():y())
		        			if dist < closest_dist then
		        				target = character
		        				closest_dist = dist
		        			end
		        		end
		        		return false
		        	end)
		        	-- We have found a target
		        	-- Create a notifier so we can null the target when they are deleted
		        	if target then
		        		local callback = function()
		        			target = nil
		        		end
		        		self:get_field():notify_on_delete(target:get_id(), self:get_id(), callback)
		        	end
		        end
			    direction = saved_direction
			    if target then
			    	local target_tile = target:get_tile()
			    	if target_tile then
			    		if target_tile:x() < tile:x() then
			    			direction = Direction.Left
			    		elseif target_tile:x() > tile:x() then
			    			direction = Direction.Right
			    		elseif target_tile:y() < tile:y() then
			    			direction = Direction.Up
			    		elseif target_tile:y() > tile:y() then
			    			direction = Direction.Down
			    		end
			    		-- Poll if target is flagged for deletion, remove our mark
			    		if target:will_erase_eof() then
			    			target = nil
			    		end
			    	end
			    end
			    local next_tile = self:get_tile(direction, 1)
                tile = next_tile
                spawn_next()
            elseif self.frames >= 60 then
                self:delete()
            end
        end
	    tatsumaki.attack_func = function(self)
	    	debug_print("Tatsumaki attacked tile ("..self:get_tile():x()..";"..self:get_tile():y()..")")
            local offset_x = math.random(-7,8)
            local offset_y = math.random(-8,7)
            local hit_fx = graphic_init("artifact", (offset_x*2), (offset_y*2), EFFECT_TEXTURE, EFFECT_PALETTE, EFFECT_ANIMPATH, -999, "0", Playback.Once, self, self:get_facing(), true, true, true)
            self:get_field():spawn(hit_fx, self:get_tile())
	    	Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Low)
	    end
        tatsumaki.collision_func = function(self)
            self:delete()
        end
        tatsumaki.battle_end_func = function(self)
            self:delete()
        end
        tatsumaki.delete_func = function(self)
            self:erase()
        end
        user:get_field():spawn(tatsumaki, tile)
    end
    spawn_next()
end

local function create_highlight(user, tile)
    local highlight = graphic_init("spell", 0, 0, false, false, false, false, false, false, user, user:get_facing())
    highlight.update_func = function(self)
        tile:highlight(Highlight.Solid)
        self:erase()
    end
    user:get_field():spawn(highlight, tile)
    return highlight
end

---@param self Entity
function package_init(self, character_info)
    -- Required function, main package information
    -- Load extra resources
    local base_animation_path = CHARACTER_ANIMATION
    self:set_texture(CHARACTER_TEXTURE)
    self.animation = self:get_animation()
    self.animation:load(base_animation_path)

    -- Set up character meta
    self:set_name(character_info.name)
    self:set_health(character_info.hp)
    self:set_height(38) -- I'm using S.S.Rockman's lock-on scope to determine the height.
    self:share_tile(false)
    self:set_explosion_behavior(4, 1, false)
    self:set_offset(0,0)
    self:set_palette(Engine.load_texture(_folderpath.."gfx/palette/battle-"..self:get_rank()..".png"))
    self.damage = character_info.damage
    self.damage_tatsumaki = character_info.damage_tatsumaki
    self.idle_frames_min = character_info.idle_frames_min
    self.idle_frames_max = character_info.idle_frames_max
    self.idle_frames = 1
    self.move_tiles = character_info.move_tiles
    self.animation:set_state("0")
    self.animation:set_playback(Playback.Loop)
    self.animation:refresh(self:sprite())
    self.frame_counter = 0
    self.started = false
    --self.defense = Battle.DefenseVirusBody.new()
    --self:add_defense_rule(self.defense)
    local super_armor_v = Battle.DefenseRule.new(814, DefenseOrder.CollisionOnly)
	super_armor_v.filter_statuses_func = function(statuses)
        if (statuses.flags & Hit.Stun == Hit.Stun) or (statuses.flags & Hit.Freeze == Hit.Freeze) then
        else
            --print("not flinching")
		    statuses.flags = statuses.flags & ~Hit.Flinch
	  	    statuses.flags = statuses.flags & ~Hit.Flash
        end
		return statuses
	end
	self:add_defense_rule(super_armor_v)

    local function check_obstacles(tile, self)
        local ob = tile:find_obstacles(function(o)
            return o:get_health() > 0 
        end)
        return #ob > 0 
    end
    local function check_characters(tile, self)
        local characters = tile:find_characters(function(c)
            return c:get_id() ~= self:get_id() and c:get_health() > 0
        end)
        return #characters > 0
    end

    self.rooted = 0
    self:register_status_callback(Hit.Root, function() self.rooted = 120 end)
    self.can_move_to_func = function(tile)
        if self.rooted > 0 then return false end
        if tile:is_edge() or not tile:is_walkable() then
            return false
        end
        if(tile:is_reserved({self:get_id()})) then
            return false
        end
        --if tile == self:get_tile() then
        --    return true
        --end
        if tile:get_team() ~= self:get_team() then
            return false
        end
        return not check_obstacles(tile, self) and not check_characters(tile, self)
    end

    ---state IDLE
    self.action_idle = function(frame)
        if (frame >= self.idle_frames) then
            ---choose move direction
            self.animation:set_state("1")
            self.animation:set_playback(Playback.Loop)
            self.animation:refresh(self:sprite())
            self.idle_frames = math.random(self.idle_frames_min,self.idle_frames_max)
            self.set_state(states.ATTACK)
        end
    end

    ---state ATTACK
    self.action_attack = function(frame)
        for i=1,20-1 do
            if frame == i then
                create_highlight(self, self:get_tile(self:get_facing(), 1))
            end
        end
        if frame == 21-1 then
            create_tatsumaki(self, self:get_tile(self:get_facing(), 1), self.move_tiles)
        elseif frame >= 80 then
            ---choose move direction
            self.animation:set_state("0")
            self.animation:set_playback(Playback.Loop)
            self.animation:refresh(self:sprite())
            self.set_state(states.IDLE)
        end
    end

    --Utility to set the update state, and reset frame counter
    self.set_state = function(state)
        self.state = state
        self.frame_counter = 0
    end

    local actions = { [1] = self.action_idle, [2] = self.action_attack }

    self.update_func = function()
        if self.rooted > 0 then self.rooted = self.rooted - 1 end
        self.frame_counter = self.frame_counter + 1
        if not self.started then
            --This runs once the battle is started
            self.started = true
            self.set_state(states.IDLE)
            self.idle_frames = math.random(self.idle_frames_min,self.idle_frames_max)
        else
            --On every frame, we will call the state action func.
            local action_func = actions[self.state]
            action_func(self.frame_counter)
        end
        check_collision(self)
    end

    function Tiletostring(tile)
        return "Tile: ["..tostring(tile:x())..","..tostring(tile:y()).."]"
    end
end

function create_collision_attack(self, tile)
    local spell = Battle.Spell.new(self:get_team())
    local hit_props = HitProps.new(
        self.damage_contact,
        Hit.Impact | Hit.Flash | Hit.Flinch,
        self:get_element(), 
        self:get_context(), 
        Drag.None
    )
    spell:set_hit_props(hit_props)
    spell.update_func = function(self)
        tile:attack_entities(self)
        self:delete()
    end
    self:get_field():spawn(spell, tile)
end

function check_collision(self)
    local t = self:get_tile()
    if self.collision_available and check_characters(t, self) then 
        create_collision_attack(self, t)
    end
end

return package_init