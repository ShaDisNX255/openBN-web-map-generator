local package_id = "com.OFC.mob.EXE1-023-Fancar"
local character_id = "com.OFC.char.EXE1-023-Fancar"

function package_requires_scripts()
    Engine.define_character(character_id, _modpath.."Fancar")
end

function package_init(package)
    package:declare_package_id(package_id)
    package:set_name("Fancar (EXE1)")
    package:set_description("Test fight with\nthe Fancar family\nfrom Rockman EXE1/OSS")
    package:set_speed(1)
    package:set_attack(80)
    package:set_health(100)
    package:set_preview_texture_path(_modpath.."preview.png")
end

function package_build(mob)
    local texPath = _modpath.."generic.png"
    local animPath = _modpath.."generic.animation"
    mob:set_background(texPath, animPath, 0.42, 0.24)
    mob:stream_music(_modpath.."exe1-virus.ogg", 1027, 47275)
    --mob:stream_music(_modpath.."exe5ds-virus-exe1.ogg", 5229, 58966)
    mob:create_spawner(character_id, Rank.V1):spawn_at(4,1)
    mob:create_spawner(character_id, Rank.V2):spawn_at(5,2)
    mob:create_spawner(character_id, Rank.V3):spawn_at(6,3)
end