--[[

    #IRREGULAR ver.:
    - Has Float and Air Shoes.
    - Much faster.
    - ShockWave is replaced with IrregularWave. Much faster. Pierces Invis. Doesn't cause Flashing. Can randomly inflict Stun, Confuse, Blind, or Root.
    - MetGuard is indestructable.

]]

local print_debug = false

local CHARACTER_TEXTURE = Engine.load_texture(_folderpath.."gfx/battle.grayscaled.png")
local CHARACTER_ANIMPATH = _folderpath.."gfx/battle.animation"
local CHARACTER_ANIMPATH_IR = _folderpath.."gfx/battle_ir.animation"

local SHOCKWAVE_TEXTURE = Engine.load_texture(_folderpath.."gfx/shockwave.grayscaled.png")
local SHOCKWAVE_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/shockwave.png")
local SHOCKWAVE_PALETTE_IR = Engine.load_texture(_folderpath.."gfx/palette/shockwave_ir.png")
local SHOCKWAVE_ANIMPATH = _folderpath.."gfx/shockwave.animation"
local MOB_MOVE_TEXTURE = Engine.load_texture(_folderpath.."gfx/mob_move.grayscaled.png")
local MOB_MOVE_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/mob_move.png")
local MOB_MOVE_ANIMPATH = _folderpath.."gfx/mob_move.animation"
local GUARD_TEXTURE = Engine.load_texture(_folderpath.."gfx/guard.grayscaled.png")
local GUARD_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/guard.png")
local GUARD_ANIMPATH = _folderpath.."gfx/guard.animation"

local GUARD_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_6.ogg", true)
local SHOCKWAVE_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_277.ogg", true)

-- Mob Tracker
local MobTracker = include("mob_tracker.lua")
local left_mob_tracker = MobTracker:new()
local right_mob_tracker = MobTracker:new()

-- Battle Chips
local Chip161 = include("chips/com_OFC_card_EXE6_161_Recovery150/recovery/recovery.lua") -- used by MetallSP and RareMetall.
Chip161.recover_hp = 150
local Chip171 = include("chips/com_OFC_card_EXE6_171_Sanctuary/stage/stage.lua") -- used by RareMetall2.
Chip171.type = 2
local Chip179 = include("chips/com_OFC_card_EXE6_179_Invisible/invisible/invisible.lua") -- used by Metall3 and RareMetall2.

local function debug_print(text)
    if print_debug then
        print("[Metall] "..text)
    end
end

--(Function by Alrysc, edited by K1rbYat1Na)
local function graphic_init(type, x, y, texture, palette, animation, layer, state, anim_playback, user, facing, delete_on_complete, relative_to_user, flip)
    texture = texture or nil
    animation = animation or nil
    layer = layer or nil
    state = state or nil
    anim_playback = anim_playback or nil
    facing = facing or nil
    delete_on_complete = delete_on_complete or false
    flip = flip or false
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(user:get_team())
    end
    if palette then
        graphic:store_base_palette(palette)
        graphic:set_palette(graphic:get_base_palette())
    end
    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then 
        graphic:set_facing(facing)
    end
    
    if relative_to_user and user:get_facing() == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end

local function shuffle(t)
    local n = #t
    while n > 1 do
        local k = math.random(n) -- Generate a random index from 1 to n
        -- Swap elements at index k and n
        t[n], t[k] = t[k], t[n] 
        n = n - 1
    end
end

function spawn_shockwave(user, tile, shockwave_state, damage_shockwave, replacement_panel, frames_before_new_attack, is_irregular)
    local spawn_next
    spawn_next = function()
        if not tile or not tile:is_walkable() then return end
        local palette = SHOCKWAVE_PALETTE
        if is_irregular then palette = SHOCKWAVE_PALETTE_IR end
        local spell = graphic_init("spell", 0, 0, SHOCKWAVE_TEXTURE, palette, SHOCKWAVE_ANIMPATH, -3, shockwave_state, Playback.Once, user, user:get_facing(), true)
        if is_irregular then
            local r=math.random(1,4)
            local stun_f={
                [1] = 90,
                [2] = 120,
                [3] = 150,
            }
            if r==1 then
                spell:set_hit_props(
                    HitProps.new()
                    :dmg(damage_shockwave)
                    :impact()
                    :flinch()
                    :stun(frames(stun_f[math.random(1,#stun_f)]))
                    :breaking()
                    :pierce()
                    :pierce_ground()
                    :retangible()
                    :from(user:get_context())
                )
            elseif r==2 then
                spell:set_hit_props(
                    HitProps.new()
                    :dmg(damage_shockwave)
                    :impact()
                    :flinch()
                    :confuse(frames(480))
                    :breaking()
                    :pierce()
                    :pierce_ground()
                    :retangible()
                    :from(user:get_context())
                )
            elseif r==3 then
                spell:set_hit_props(
                    HitProps.new()
                    :dmg(damage_shockwave)
                    :impact()
                    :flinch()
                    :blind(frames(480))
                    :breaking()
                    :pierce()
                    :pierce_ground()
                    :retangible()
                    :from(user:get_context())
                )
            else
                spell:set_hit_props(
                    HitProps.new()
                    :dmg(damage_shockwave)
                    :impact()
                    :flinch()
                    :root(frames(stun_f[math.random(1,#stun_f)]))
                    :breaking()
                    :pierce()
                    :pierce_ground()
                    :retangible()
                    :from(user:get_context())
                )
            end
        elseif replacement_panel then
            spell:set_hit_props(
                HitProps.new()
                :dmg(damage_shockwave)
                :impact()
                :flinch()
                :flash()
                :pierce_ground()
                :retangible()
                :from(user:get_context())
            )
        else
            spell:set_hit_props(
                HitProps.new()
                :dmg(damage_shockwave)
                :impact()
                :flinch()
                :flash()
                :from(user:get_context())
            )
        end
        spell.frames = 0
        spell.on_spawn_func = function(self)
            debug_print("ShockWave spawned on tile ("..tile:x()..";"..tile:y()..")")
            if is_irregular then
                self:shake_camera(20, 0.033)
            end
            Engine.play_audio(SHOCKWAVE_AUDIO, AudioPriority.Immediate)
            if replacement_panel then -- Replaces tile only on spawn.
                if replacement_panel == TileState.Cracked and self:get_tile():is_cracked() then
                    self:get_tile():set_state(TileState.Broken)-- Breaks tile if is cracked already.
                else
                    self:get_tile():set_state(replacement_panel)
                end
            end
        end
        spell.update_func = function(self)
            self:get_tile():attack_entities(self)
            if not self:get_tile():is_walkable() then
                self:erase()
            end
            self.frames = self.frames + 1
            if self.frames >= 1 then
                self:highlight_tile(Highlight.Solid)
                if self.frames == frames_before_new_attack then
                    tile = tile:get_tile(self:get_facing(), 1)
                    spawn_next()
                end
            end
        end
        spell.attack_func = function(self, other, judge)
            debug_print("ShockWave attacked tile ("..self:get_tile():x()..";"..self:get_tile():y()..")")
            if not judge:hint_spawn_gfx() then return end
        end
        spell.battle_end_func = function(self)
            self:erase()
        end
        user:get_field():spawn(spell, tile)
    end
    spawn_next()
end

function get_tracker_from_direction(facing)
    if facing == Direction.Left then
        return left_mob_tracker
    elseif facing == Direction.Right then
        return right_mob_tracker
    end
end

function advance_a_turn_by_facing(facing)
    local mob_tracker = get_tracker_from_direction(facing)
    return mob_tracker:advance_a_turn()
end

function get_active_mob_id_for_same_direction(facing)
    local mob_tracker = get_tracker_from_direction(facing)
    return mob_tracker:get_active_mob()
end

function add_enemy_to_tracking(enemy)
    local facing = enemy:get_facing()
    local id = enemy:get_id()
    local mob_tracker = get_tracker_from_direction(facing)
    mob_tracker:add_by_id(id)
end

function remove_enemy_from_tracking(enemy)
    local facing = enemy:get_facing()
    local id = enemy:get_id()
    local mob_tracker = get_tracker_from_direction(facing)
    mob_tracker:remove_by_id(id)
end

function package_init(self, character_info)
    debug_print("package_init called")
    -- Required function, main package information
    self.is_irregular = false
    if self:get_rank() == Rank.NM then
        self.is_irregular = true
    end

    -- Load character resources
    self.texture = CHARACTER_TEXTURE
    self.animpath = CHARACTER_ANIMPATH
    if self.is_irregular then
        self.animpath = CHARACTER_ANIMPATH_IR
    end
    self.animation = self:get_animation()
    self.animation:load(self.animpath)

    -- Load extra resources

    -- Set up character meta
    self:set_name(character_info.name)
    self:set_health(character_info.health)
    self:set_texture(self.texture, true)
    self:set_height(22)
    self:share_tile(false)
    self:set_explosion_behavior(2, 1, false)
    self:set_offset(0,0)
    if not self.is_irregular then
        self:store_base_palette(Engine.load_texture(_folderpath.."gfx/palette/battle-"..self:get_rank()..".png"))
        self:set_palette(self:get_base_palette())
    else
        self:store_base_palette(Engine.load_texture(_folderpath.."gfx/palette/battle-0.png"))
        self:set_float_shoe(true)
        self:set_air_shoe(true)
    end

    -- DefenseRules
    self.defense = Battle.DefenseVirusBody.new()
    self:add_defense_rule(self.defense)

    -- Initial state
    self.animation:set_state("PLAYER_IDLE")
    self.animation:set_playback(Playback.Loop)
    self.damage = character_info.damage
    self.frames_between_actions = character_info.move_delay
    self.frames_before_new_attack = character_info.shockwave_frames -- lower = faster ShockWaves
    self.shockwave_state = character_info.shockwave_state -- upper = faster ShockWaves
    self.damage_shockwave = character_info.damage_shockwave
    self.can_guard = character_info.can_guard
    self.replacement_panel = character_info.replacement_panel
    self.ai_wait = 36
    if self.is_irregular then
        self.ai_wait = 1
    end
    self.ai_taken_turn = false

    --Battle Chips
    self.battle_chip_start = false
    self.battle_chip_timer = 300
    self.battle_chip_amount = 0
    self.battle_chip = nil
    self.battle_chip_id = 0

    -- Name Shuffler (only for #IRREGULAR)
    self.name_shuffler = Battle.Component.new(self, Lifetimes.Scene)
    self.name_shuffler.char1 = {"M","m"}
    self.name_shuffler.char2 = {"E","e","3"}
    self.name_shuffler.char3 = {"T","t"}
    self.name_shuffler.char4 = {"A","a","4"}
    self.name_shuffler.char5 = {"L","l"}
    self.name_shuffler.char6 = {"L","l"}
    self.name_shuffler.frames = 0
    self.name_shuffler.palstate = 0
    self.name_shuffler.paldir = 1
    self.name_shuffler.orig_name = self:get_name()
    self.name_shuffler.invic = {}
    self.name_shuffler.invic.active = false
    self.name_shuffler.invic.color = 0
    self.name_shuffler.invic.dir = 1
    self.name_shuffler.update_func = function(shuf)
        local new_name = nil
        if math.random(4,444) == 4 then
            new_name = "4444444"
        else
            local new_name_t = {}
            for i=1, 6 do
                table.insert(new_name_t, shuf["char"..i][math.random(1, #shuf["char"..i])])
            end
            shuffle(new_name_t)
            new_name = table.concat(new_name_t)
        end
        self:set_name(new_name)
        shuf.frames = shuf.frames+1
        if shuf.frames%5 == 0 then
            shuf.palstate = shuf.palstate + (1*shuf.paldir)
            if shuf.palstate > 5 or shuf.palstate < -5 then
                shuf.paldir = -shuf.paldir
                shuf.palstate = shuf.palstate + (2*shuf.paldir)
            end
            self:set_palette(Engine.load_texture(_folderpath.."gfx/palette/irregular/battle"..shuf.palstate..".png"))
        end

        if shuf.invic.active then
            shuf.invic.color = shuf.invic.color + 15*shuf.invic.dir
            if shuf.invic.color > 255 or shuf.invic.color < 0 then
                shuf.invic.dir = -shuf.invic.dir
                shuf.invic.color = shuf.invic.color + 15*shuf.invic.dir
            end
            self:sprite():set_color_mode(ColorMode.Additive)
            self:set_color(Color.new(0,math.floor(shuf.invic.color),math.floor(shuf.invic.color),255))
        end
    end
    self.invicibility_defense_rule = Battle.DefenseRule.new(0, DefenseOrder.Always)
    self.invicibility_defense_rule.can_block_func = function(judge, attacker, defender)
        judge:hint_spawn_gfx(true)
        judge:block_damage()
    end

    self.can_move_to_func = function(tile)
        --if self:is_rooted() then return false end
        if not self.is_irregular then
            if tile:is_edge() or not tile:is_walkable() then
                return false
            end
        else
            if tile:is_edge() then
                return false
            end
            if tile:is_hole() then
                return not check_obstacles(tile) and not check_characters_true(tile)
            end
        end
        if(tile:is_reserved({self:get_id()})) then
            return false
        end
        if tile == self:get_tile() then
            return true
        end
        if tile:get_team() ~= self:get_team() then
            return false
        end
        return not check_obstacles(tile) and not check_characters_true(tile)
    end
    self.orig_playback_speed = self:get_animation():get_playback_speed()
    self.orig_playback_speed_do_once = true
    self.update_func = function(self)
        if not self:is_dragged() then
            --print("NO_SLIDE")
            --if not self.orig_playback_speed_do_once then
                --self.orig_playback_speed_do_once = true
                --self:get_animation():set_playback_speed(self.orig_playback_speed)
            --end
            if self.battle_chip_start then
                if self.battle_chip_timer > 0 then
                    self.battle_chip_timer = self.battle_chip_timer - 1
                else
                    if self.battle_chip_amount <= 0 then
                        self.battle_chip_start = false
                    end
                end
            end
            local facing = self:get_facing()
            local field = self:get_field()
            local id = self:get_id()
            local active_mob_id = get_active_mob_id_for_same_direction(facing)
            if (self:is_rooted() and self:get_tile():get_state() ~= TileState.Sand and self:get_tile():get_state() ~= TileState.Sea) then
            else
                if active_mob_id == id then
                    --print("NO_SLIDE take_turn")
                    take_turn(self)
                else
                    --print("NO_SLIDE idle_action")
                    idle_action(self)
                end
            end
        else
            --print("SLIDE")
            --if self.orig_playback_speed_do_once then
                --self.orig_playback_speed_do_once = false
                --self:get_animation():set_playback_speed(0)
            --end
        end
        check_collision(self)
    end
    self.battle_start_func = function(self)
        debug_print("battle_start_func called")
        if self.battle_chip_id ~= 161 then
            self.battle_chip_start = true
        end
        if left_mob_tracker:get_first_mob(false) == nil then
            left_mob_tracker:clear()
        end
        if right_mob_tracker:get_first_mob(true) == nil then
            right_mob_tracker:clear()
        end
        add_enemy_to_tracking(self)
        local field = self:get_field()
        local mob_sort_func = function(a,b)
            local met_a_tile = field:get_entity(a):get_tile()
            local met_b_tile = field:get_entity(b):get_tile()
            local var_a = (met_a_tile:x()*3)+met_a_tile:y()
            local var_b = (met_b_tile:x()*3)+met_b_tile:y()
            return var_a < var_b
        end
        left_mob_tracker:sort_turn_order(mob_sort_func)
        right_mob_tracker:sort_turn_order(mob_sort_func,true)--reverse sort direction
    end
    self.battle_end_func = function(self)
        debug_print("battle_end_func called")
        left_mob_tracker:clear()
        right_mob_tracker:clear()
    end
    self.on_spawn_func = function(self, spawn_tile)
        debug_print("on_spawn_func called")
        if not self.is_irregular then
            if character_info.name_on_spawn then
                self:set_name(character_info.name)
            end
        else
            self:register_component(self.name_shuffler)
        end
        if self:get_rank() == Rank.V3 then
            if math.random(1,16) <= 3 then
                self.battle_chip_amount = 1
                self.battle_chip = Chip179
                self.battle_chip_id = 179
                if self.battle_chip_amount == 1 then
                    print("Metall3 has a BattleChip: Invisible")
                elseif self.battle_chip_amount > 1 then
                    print("Metall3 has "..self.battle_chip_amount.." BattleChips: Invisible")
                end
            end
        elseif self:get_rank() == Rank.SP then
            if math.random(1,16) <= 3 then
                self.battle_chip_amount = 1
                self.battle_chip = Chip161
                self.battle_chip_id = 161
                if self.battle_chip_amount == 1 then
                    print("MetallSP has a BattleChip: Recovery150")
                elseif self.battle_chip_amount > 1 then
                    print("MetallSP has "..self.battle_chip_amount.." BattleChips: Recovery150")
                end
            end
        elseif self:get_rank() == Rank.Rare1 then
            self.battle_chip_amount = 1
            self.battle_chip = Chip161
            self.battle_chip_id = 161
            if self.battle_chip_amount == 1 then
                print("RareMetall has a BattleChip: Recovery150")
            elseif self.battle_chip_amount > 1 then
                print("RareMetall has "..self.battle_chip_amount.." BattleChips: Recovery150")
            end
        elseif self:get_rank() == Rank.Rare2 then
            local chance = math.random(1,16)
            if chance <= 2 then
                self.battle_chip_amount = 1
                self.battle_chip = Chip171
                self.battle_chip_id = 171
                if self.battle_chip_amount == 1 then
                    print("RareMetall2 has a BattleChip: Sanctuary")
                elseif self.battle_chip_amount > 1 then
                    print("RareMetall2 has "..self.battle_chip_amount.." BattleChips: Sanctuary")
                end
            elseif chance <= 12 then
                self.battle_chip_amount = 1
                self.battle_chip = Chip179
                self.battle_chip_id = 179
                if self.battle_chip_amount == 1 then
                    print("RareMetall2 has a BattleChip: Invisible")
                elseif self.battle_chip_amount > 1 then
                    print("RareMetall2 has "..self.battle_chip_amount.." BattleChips: Invisible")
                end
            end
        end
        --In theory we should not need to do this as they would be cleared at the end of the last battle
        --However there is a bug in ONB V2 which causes battle_end_func to be missed sometimes.
        left_mob_tracker:clear()
        right_mob_tracker:clear()
    end
    --[[
    self.can_move_to_func = function(tile)
        debug_print("can_move_to_func called")
        return is_tile_free_for_movement(tile,self)
    end
    ]]
    self.delete_func = function(self) 
        debug_print("delete_func called")
        remove_enemy_from_tracking(self)
        if self.is_irregular then
            self.name_shuffler:eject()
        end
    end
end

function create_collision_attack(user, tile)
    local spell = Battle.Spell.new(user:get_team())
    spell:set_facing(user:get_facing())
    local hit_props = HitProps.new()
    :dmg(user.damage)
    :impact()
    :flinch()
    :flash()
    :from(user:get_context())
    :elem(user:get_element())
    spell:set_hit_props(hit_props)
    spell.update_func = function(self)
        tile:attack_entities(self)
        self:delete()
    end
    user:get_field():spawn(spell, tile)
end

function check_collision(user)
    local t = user:get_tile()
    if user.collision_available and check_characters(t, user) then 
        create_collision_attack(user, t)
    end
end

function find_target(self)
    local field = self:get_field()
    local team = self:get_team()
    local target_list = field:find_characters(function(other_character)
        return other_character:get_team() ~= team
    end)
    if #target_list == 0 then
        debug_print("No targets found!")
        return
    end
    local target_character = target_list[1]
    return target_character
end

function idle_action(self)
    if self.can_guard then
        --if the mettaur can guard, queue up a guard for after the current action
        if self.guarding_defense_rule then
            local anim = self:get_animation()
            anim:set_state("GUARDING")
        elseif not self.guard_transition then
            begin_guard(self)
        end
    end
end

function end_guard(character)
    if character.is_irregular then
        character:remove_defense_rule(character.invicibility_defense_rule)
        character.name_shuffler.invic.active = false
        character.name_shuffler.invic.color = 0
        character.name_shuffler.invic.dir = 1
    end
    character.guard_transition = true
    local anim = character:get_animation()
    anim:set_state("GUARD_OFF")
    anim:set_playback(Playback.Once)
    character:remove_defense_rule(character.guarding_defense_rule)
    character.guarding_defense_rule = nil
    anim:on_complete(function()
        character.guard_transition = false
        character.ai_wait = 36
        if character.is_irregular then
            character.ai_wait = 1
        end
	end)
end

function begin_guard(character)
    if character.is_irregular then
        character:add_defense_rule(character.invicibility_defense_rule)
        character.name_shuffler.invic.active = true
    end
    character.guard_transition = true
    local anim = character:get_animation()
    anim:set_state("GUARD_ON")
    anim:set_playback(Playback.Once)
    anim:on_complete(function()
        character.guard_transition = false
        character.guarding_defense_rule = Battle.DefenseRule.new(1, DefenseOrder.Always)
        character.guarding_defense_rule.can_block_func = function(judge, attacker, defender)
            if not character.is_irregular then
                local hit_props = attacker:copy_hit_props()
                if hit_props:has_flags(Hit.Breaking) then
                    --cant block breaking hits with guard
                else
                    judge:block_damage()
                    if hit_props:has_flags(Hit.Impact) then
                        local offset_y = math.random(-24,-9)
                        local offset_x = math.random(-9,8) --math.random(-9,5)
                        if character:get_facing() == Direction.Left then offset_x = -offset_x end
                        local hit_fx = graphic_init("artifact", character:get_tile_offset().x+character:get_offset().x+(offset_x*2), character:get_tile_offset().y+character:get_offset().y+(offset_y*2), GUARD_TEXTURE, GUARD_PALETTE, GUARD_ANIMPATH, -999, "0", Playback.Once, character, character:get_facing(), true, false, true)
                        character:get_field():spawn(hit_fx, character:get_tile())
                        Engine.play_audio(GUARD_AUDIO, AudioPriority.Immediate)
                    end
                end
            end
        end
        character:add_defense_rule(character.guarding_defense_rule)
	end)
end

function take_turn(self)
    --print("take_turn")
    --print("ai_wait: "..self.ai_wait)
    local id = self:get_id()
    --print("taking turn "..id)
    if self.ai_wait > 0 or self.ai_taken_turn then
        self.ai_wait = self.ai_wait - 1
        if not self.guarding_defense_rule and not self.guard_transition and not self.shockwave_action then
            local anim = self:get_animation()
            anim:set_state("PLAYER_IDLE")
        end
        return
    end
    self.ai_taken_turn = true
    if self.guarding_defense_rule and not self.guard_transition then
        if self:is_confused() or self:is_blind() then
            if not self.is_irregular then
                self.ai_wait = 90
            else
                self.ai_wait = 30
            end
        else
            self.ai_wait = self.frames_between_actions
        end
        self.ai_wait = 90
        self.ai_taken_turn = false
        end_guard(self)
        return
    end
    --print("NO ROOT")
    self.attack_immediatly = false
    if not self.attack_immediatly then
        local moved = move_towards_character(self)
        if moved then
            if self:is_confused() or self:is_blind() then
                if not self.is_irregular then
                    self.ai_wait = 90
                else
                    self.ai_wait = 30
                end
            else
                self.ai_wait = self.frames_between_actions
            end
            self.ai_taken_turn = false
            return
        end
    end
    self.shockwave_action = action_shockwave(self)
    self.shockwave_action.action_end_func = function()
        local facing = self:get_facing()
        if self:is_confused() or self:is_blind() then
            if not self.is_irregular then
                self.ai_wait = 90
            else
                self.ai_wait = 30
            end
        else
            self.ai_wait = self.frames_between_actions
        end
        self.ai_taken_turn = false
        self.shockwave_action = nil
        advance_a_turn_by_facing(facing)
    end
    if not self.guard_transition and self.ai_wait <= 0 then
        --print("can action")
        if self.battle_chip_amount > 0 and ((self.battle_chip_id == 161 and self:get_health() <= (self:get_max_health()-(self:get_max_health()*75)/100)) or (self.battle_chip_id ~= 161 and self.battle_chip_timer <= 0)) then
            debug_print("using Chip")
            self.battle_chip_amount = self.battle_chip_amount - 1
            local chip_action = self.battle_chip.card_create_action(self)
            local props = chip_action:copy_metadata()
            if self.battle_chip_id == 161 then
                props.shortname = "Recov150"
                props.damage = 0
                props.time_freeze = false
                props.element = Element.None
                props.can_boost = false
            elseif self.battle_chip_id == 171 then
                props.shortname = "Snctuary"
                props.damage = 0
                props.time_freeze = true
                props.element = Element.None
                props.can_boost = false
            elseif self.battle_chip_id == 179 then
                props.shortname = "Invisibl"
                props.damage = 0
                props.time_freeze = true
                props.element = Element.None
                props.can_boost = false
            end
            chip_action = self.battle_chip.card_create_action(self, props)
	        chip_action:set_metadata(props)
            self:card_action_event(chip_action, ActionOrder.Voluntary)
            --chip_action.action_end_func = function()
                --self.battle_chip_timer = 300
                self.ai_taken_turn = false
            --end
        else
            if self:can_attack() --[[and not self:is_moving()]] then
                debug_print("using Wave")
                action_shockwave1(self)
                --self:card_action_event(self.shockwave_action, ActionOrder.Voluntary)
                self.attack_immediatly = false
            end
        end
    end
end

function move_towards_character(self)
    self.guard_transition = true
    local target_character = find_target(self)
    local target_character_tile = target_character:get_tile()
    local tile = self:get_tile()
    local moved = false
    local target_movement_tile = nil
    if tile:y() < target_character_tile:y() then
        target_movement_tile = tile:get_tile(Direction.Down, 1)
    end
    if tile:y() > target_character_tile:y() then
        target_movement_tile = tile:get_tile(Direction.Up, 1)
    end
    local random_action = nil
    if self:is_confused() or self:is_blind() then
        random_action = math.random(1,3)
        if random_action == 1 then
            target_movement_tile = tile:get_tile(Direction.Down, 1)
            if not self.can_move_to_func(target_movement_tile) then
                target_movement_tile = tile:get_tile(Direction.Up, 1)
            end
        elseif random_action == 2 then
            target_movement_tile = tile:get_tile(Direction.Up, 1)
            if not self.can_move_to_func(target_movement_tile) then
                target_movement_tile = tile:get_tile(Direction.Down, 1)
            end
        else
            --[[
            random_action2 = math.random(1,2)
            if random_action2 == 1 then
                target_movement_tile = tile:get_tile(Direction.Down, 1)
                if not self.can_move_to_func(target_movement_tile) then
                    target_movement_tile = tile:get_tile(Direction.Up, 1)
                end
            else
                target_movement_tile = tile:get_tile(Direction.Up, 1)
                if not self.can_move_to_func(target_movement_tile) then
                    target_movement_tile = tile:get_tile(Direction.Down, 1)
                end
            end]]
            target_movement_tile = nil
            self.attack_immediatly = true
        end
    end
    local anim = self:get_animation()
    if target_movement_tile and self.can_move_to_func(target_movement_tile) then
        anim:set_state("PLAYER_MOVE")
        self:get_animation():on_frame(1, function()
            target_movement_tile:reserve_entity_by_id(self:get_id())
            if self.can_move_to_func(target_movement_tile) then
                local move_fx = graphic_init("artifact", 0, -8*2, MOB_MOVE_TEXTURE, MOB_MOVE_PALETTE, MOB_MOVE_ANIMPATH, -99, "0", Playback.Once, self, self:get_facing(), true, false, true)
                self:get_field():spawn(move_fx, tile)
            else
                anim:set_state("PLAYER_IDLE")
                self.guard_transition = false
                return false
                --return moved
            end
        end)
        self:get_animation():on_complete(function()
            anim:set_state("PLAYER_IDLE")
            self:teleport(target_movement_tile, ActionOrder.Immediate)
            if self:is_confused() or self:is_blind() then
                if self.attack_immediatly then
                    self.ai_wait = 0
                else
                    self.ai_wait = 90
                end
            else
                self.ai_wait = self.frames_between_actions
            end
            self.ai_taken_turn = false
            self.guard_transition = false
            return true
            --moved = self:teleport(target_movement_tile, ActionOrder.Immediate)
            --return moved
        end)
    else
        anim:set_state("PLAYER_IDLE")
        self.guard_transition = false
        return false
        --return moved
    end
    --[[
    if target_movement_tile then
        moved = self:teleport(target_movement_tile, ActionOrder.Immediate)
        if moved then
            --print("moving")
            local move_fx = graphic_init("artifact", 0, -8*2, MOB_MOVE_TEXTURE, MOB_MOVE_ANIMPATH, "0", Playback.Once, -99, self, self:get_facing(), true)
            move_fx:set_palette(MOB_MOVE_PALETTE)
            move_fx:get_animation():on_complete(function() move_fx:erase() end)
            self:get_field():spawn(move_fx, tile)
        end
    end
    ]]
    --return moved
end

function action_shockwave(character)
    local action_name = "ShockWave"
    debug_print('action '..action_name)

    local action = Battle.CardAction.new(character, "ATTACK")
	action:set_lockout(make_animation_lockout())
    action.execute_func = function(self, user)
        self:add_anim_action(6, function()
            character:toggle_counter(true)
        end)
		self:add_anim_action(14, function()
            spawn_shockwave(character, character:get_tile(character:get_facing(), 1))
        end)
        self:add_anim_action(17, function()
            character:toggle_counter(false)
        end)
	end
    return action
end

function action_shockwave1(self)
    self.guard_transition = true
    local anim = self:get_animation()
    anim:set_state("ATTACK")
    anim:on_frame(6, function()
        self:toggle_counter(true)
    end)
	anim:on_frame(14, function()
        local tile = self:get_tile(self:get_facing(), 1)
        spawn_shockwave(self, tile, self.shockwave_state, self.damage_shockwave, self.replacement_panel, self.frames_before_new_attack, self.is_irregular)
    end)
    anim:on_frame(17, function()
        self:toggle_counter(false)
    end)
    anim:on_complete(function()
        self.guard_transition = false
        local facing = self:get_facing()
        if self:is_confused() or self:is_blind() then
            if not self.is_irregular then
                self.ai_wait = 90
            else
                self.ai_wait = 30
            end
        else
            self.ai_wait = self.frames_between_actions
        end
        self.ai_taken_turn = false
        self.shockwave_action = nil
        advance_a_turn_by_facing(facing)
    end)
end

--[[
function is_tile_free_for_movement(tile,character)
    --Basic check to see if a tile is suitable for a chracter of a team to move to
    if tile:get_team() ~= character:get_team() then return false end
    if not tile:is_walkable() then return false end
    local occupants = tile:find_characters(function(other_character)
        return true
    end)
    if #occupants > 0 then 
        return false
    end
    return true
end
]]

-- Checks for non-zero-health Obstacles.
function check_obstacles(tile)
    local ob = tile:find_obstacles(function(o)
        if o:get_animation():has_state("PASS_THROUGH") or o:get_name() == "CANTINTERACT" then
            return false
        else
            return true
        end
        return o:get_health() > 0
    end)
    return #ob > 0 
end

-- Checks for unfriendly Characters.
function check_characters(tile, self)
    local characters = tile:find_characters(function(c)
        return c:get_id() ~= self:get_id() and c:get_team() ~= self:get_team()
    end)
    return #characters > 0
end

-- Checks for any Characters.
function check_characters_true(tile)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0
    end)
    return #characters > 0
end

return package_init