local print_debug = false

local STAGE_AUDIO1 = Engine.load_audio(_folderpath.."sfx/EXE6_173.ogg", true)
local STAGE_AUDIO2 = Engine.load_audio(_folderpath.."sfx/EXE6_241.ogg", true)

local function debug_print(text)
    if print_debug then
        print("[StageChange] "..text)
    end
end

local stage = {}

stage.card_create_action = function(user, props)
    debug_print("in create_card_action()!")
    local action = Battle.CardAction.new(user, "PLAYER_IDLE")
	action:set_lockout(make_sequence_lockout())
	action.execute_func = function(self, user)
        debug_print("in custom card action execute_func()!")
        local actor = self:get_actor()
        local orig_speed = actor:get_animation():get_playback_speed()
        actor:get_animation():set_playback_speed(0)

		local facing = user:get_facing()
		local field = user:get_field()
		local tile1 = user:get_tile(facing, 1)
		local all_red_tiles_no_hole = field:find_tiles(function(tile) 
			return not tile:is_edge() and not tile:is_hole() and tile:get_team() == user:get_team()
		end)
		local all_red_tiles = field:find_tiles(function(tile) 
			return not tile:is_edge() and tile:get_state() ~= TileState.Empty and tile:get_state() ~= TileState.Hidden and tile:get_team() == user:get_team()
		end)
		local enemy_line = field:find_tiles(function(tile) 
			return not tile:is_edge() and tile:get_state() ~= TileState.Empty and tile:get_state() ~= TileState.Hidden and tile:y() == user:get_tile():y() and tile:get_team() ~= user:get_team()
		end)
		local k = 0
		local cooldown = 0
		local is_reveal = false
		local original_state_table = {}
		local step1 = Battle.Step.new()
		local do_once = true
		step1.update_func = function(self, dt)
			if cooldown <= 0 then
				k = k + 1
				cooldown = 0.033
				if do_once then
					do_once = false
					if     stage.type == 1 then
						if tile1:get_state() ~= TileState.Empty and tile1:get_state() ~= TileState.Hidden then
							table.insert(original_state_table, tile1:get_state())
						end
					elseif stage.type == 0 then
						for i=1, #all_red_tiles_no_hole do
							table.insert(original_state_table, all_red_tiles_no_hole[i]:get_state())
						end
					elseif stage.type == 2 then
						for i=1, #all_red_tiles do
							table.insert(original_state_table, all_red_tiles[i]:get_state())
						end
					elseif stage.type == 3 or stage.type == 4 then
						for i=1, #enemy_line do
							table.insert(original_state_table, enemy_line[i]:get_state())
						end
					end
				end
				Engine.play_audio(STAGE_AUDIO1, AudioPriority.Immediate)
				if is_reveal then
					is_reveal = false
					if     stage.type == 1 then
						if tile1:get_state() ~= TileState.Empty and tile1:get_state() ~= TileState.Hidden then
							tile1:set_state(original_state_table[1])
						end
					elseif stage.type == 0 then
						for j=1, #all_red_tiles_no_hole do
							all_red_tiles_no_hole[j]:set_state(original_state_table[j])
						end
					elseif stage.type == 2 then
						for j=1, #all_red_tiles do
							all_red_tiles[j]:set_state(original_state_table[j])
						end
					elseif stage.type == 3 or stage.type == 4 then
						for j=1, #enemy_line do
							enemy_line[j]:set_state(original_state_table[j])
						end
					end
				else
					is_reveal = true
					if 	   stage.type == 1 then
						if tile1:get_state() ~= TileState.Empty and tile1:get_state() ~= TileState.Hidden then
							tile1:set_state(TileState.Holy)
						end
					elseif stage.type == 0 then
						for j=1, #all_red_tiles_no_hole do
							all_red_tiles_no_hole[j]:set_state(TileState.Normal)
						end
					elseif stage.type == 2 then
						for j=1, #all_red_tiles do
							all_red_tiles[j]:set_state(TileState.Holy)
						end
					elseif stage.type == 3 or stage.type == 4 then
						for j=1, #enemy_line do
							if 	   (stage.type == 3 and facing == Direction.Right) or (stage.type == 4 and facing == Direction.Left ) then
								enemy_line[j]:set_state(TileState.DirectionLeft)
							elseif (stage.type == 3 and facing == Direction.Left ) or (stage.type == 4 and facing == Direction.Right) then
								enemy_line[j]:set_state(TileState.DirectionRight)
							end
						end
					end
				end
			else
				cooldown = cooldown - dt
			end
			if k == 17 then
				Engine.play_audio(STAGE_AUDIO2, AudioPriority.Immediate)
                user:get_animation():set_playback_speed(orig_speed)
				self:complete_step()
			end	
		end
		self:add_step(step1)
	end
	return action
end

return stage