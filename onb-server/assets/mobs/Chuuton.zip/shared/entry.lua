local AUDIO_DAMAGE = Engine.load_audio(_folderpath.."EXE4_270.ogg")
local AUDIO_DAMAGE_OBS = Engine.load_audio(_folderpath.."EXE4_221.ogg")
local MOB_MOVE_TEXTURE = Engine.load_texture(_folderpath.."mob_move.png")
local MOB_MOVE_ANIMPATH = _folderpath.."mob_move.animation"

local CHARACTER_TEXTURE = Engine.load_texture(_folderpath.."battle.grayscaled.png")
local CHARACTER_ANIMATION = _folderpath.."battle.animation"
local RATTON_TEXTURE = Engine.load_texture(_folderpath.."ratton.grayscaled.png")
local RATTON_ANIMPATH = _folderpath.."ratton.animation"
local RATTON_AUDIO = Engine.load_audio(_folderpath.."EXE3_169.ogg")
local BOOM_TEXTURE = Engine.load_texture(_folderpath.."boom.png")
local BOOM_ANIMPATH = _folderpath.."boom.animation"
local BOOM_AUDIO = Engine.load_audio(_folderpath.."EXE4_273.ogg")

local debug = false
local function debug_print(text)
    if debug then
        print("[Chuuton] "..text)
    end
end

function package_init(self, character_info)
    -- Required function, main package information
    local base_animation_path = CHARACTER_ANIMATION
    self:set_texture(CHARACTER_TEXTURE)
    self.animation = self:get_animation()
    self.animation:load(base_animation_path)
    -- Set up character meta
    self:set_palette(Engine.load_texture(character_info.palette))
    self:set_name(character_info.name)
    self.name = character_info.name
    self:set_health(character_info.hp)
    self:set_height(22)
    self.damage = (character_info.damage)
    self:set_element(Element.None)
    self:set_explosion_behavior(3, 1, false)
    self.animation:set_state("SPAWN")
    self:share_tile(false)
    self:set_offset(0, 0)
    self.type = character_info.type
    self.damage = character_info.damage
    self._move_before_attack = character_info.move_before_attack
    self._slide_speed = character_info.slide_speed
    self._angry_slide_speed = character_info.angry_slide_speed
    self._pause_between_moves = 10
    self._pause_between_moves_angry = 5
    self._idle_state = "0"
    self._angry_idle_state = "1"
    self._attack_state = "2"
    self._angry_attack_state = "3"
    self._current_moves = 0
    self._ratton_move_speed = self._slide_speed
    self._wait_after_bombing = 0
    self.battle_start_func = function(self)
        debug_print("battle_start_func called")
        self.animation:set_state(self._idle_state)
        self.animation:set_playback(Playback.Loop)
    end
    local is_occupied = function(ent)
        return (Battle.Character.from(ent) ~= nil and ent:get_id() ~= self:get_id()) or Battle.Obstacle.from(ent) ~= nil
    end
    self.can_move_to_func = function(tile)
        return self:is_team(tile:get_team()) and tile:is_walkable() and not tile:is_edge() and #tile:find_entities(is_occupied) <= 0 and not tile:is_reserved({self:get_id()})
    end
    local has_changed_pattern = false
    local direction_table = {Direction.Up, Direction.Down, Direction.Left, Direction.Right}
    local random_move_direction = Direction.None
    local new_direction = Direction.None
    local has_picked_direction = false
    self.do_once = true
    local field = nil
    --[[
    self.defense = Battle.DefenseVirusBody.new() -- lua owns this need to keep it alive
    self:add_defense_rule(self.defense)
    ]]
    self.spawn_func = function(self)
        debug_print("spawn_func called")
        field = self:get_field()
    end
    self.update_func = function(self, dt)
        --[[
        if self:get_health() <= math.floor(self:get_max_health()/2) and not has_changed_pattern then
            self._slide_speed = self._angry_slide_speed
            self._pause_between_moves = self._pause_between_moves_angry
            self._idle_state = self._angry_idle_state
            self._attack_state = self._angry_attack_state
            has_changed_pattern = true
            self.animation:set_state(self._idle_state)
            self.animation:set_playback(Playback.Loop)
        end
        ]]
        if self._current_moves < self._move_before_attack then
            if self._wait_after_bombing <= 0 then
                if not has_picked_direction and not self:is_sliding() then
                    random_move_direction = direction_table[math.random(1, #direction_table)]
                    local next_tile = self:get_tile(random_move_direction, 1)
                    if self.can_move_to_func(next_tile) then
                        next_tile:reserve_entity_by_id(self:get_id())
                        has_picked_direction = true
                    else
                        new_direction = Direction.flip_x(random_move_direction)
                        next_tile = self:get_tile(new_direction, 1)
                        if self.can_move_to_func(next_tile) then
                            next_tile:reserve_entity_by_id(self:get_id())
                            has_picked_direction = true
                            random_move_direction = new_direction
                        else
                            new_direction = Direction.flip_y(random_move_direction)
                            next_tile = self:get_tile(new_direction, 1)
                            if self.can_move_to_func(next_tile) then
                                next_tile:reserve_entity_by_id(self:get_id())
                                has_picked_direction = true
                                random_move_direction = new_direction
                            else
                                new_direction = Direction.reverse(random_move_direction)
                                next_tile = self:get_tile(new_direction, 1)
                                if self.can_move_to_func(next_tile) then
                                    next_tile:reserve_entity_by_id(self:get_id())
                                    has_picked_direction = true
                                    random_move_direction = new_direction
                                end
                            end
                        end
                    end
                else
                    if not self:is_sliding() then
                        self:slide(self:get_tile(random_move_direction, 1), frames(self._slide_speed), frames(self._pause_between_moves), ActionOrder.Immediate, function()
                            self._current_moves = self._current_moves + 1
                        end)
                        has_picked_direction = false
                    end
                end
            else
                self._wait_after_bombing = self._wait_after_bombing - 1
            end
        else
            if not self:is_sliding() and self.do_once then
                self.animation:set_state(self._attack_state)
                self.animation:set_playback(Playback.Once)
                self.animation:on_frame(3, function()
                    local spawn_tile = self:get_tile(self:get_facing(), 1)
                    Engine.play_audio(RATTON_AUDIO, AudioPriority.Low)
                    create_ratton(self, spawn_tile)
                end)
                self.animation:on_complete(function()
                    self.animation:set_state(self._idle_state)
                    self.animation:set_playback(Playback.Loop)
                    self._current_moves = 0
                    self.do_once = true
                    self._wait_after_bombing = 10
                end)
                self.do_once = false
            end
        end
    end
end

function create_ratton(user, tile)
    local spawn_next
    spawn_next = function()
        if not tile:is_walkable() then return end
        local team = user:get_team()
        local field = user:get_field()
        local facing = user:get_facing()

	    local spell = Battle.Spell.new(team)
	    spell:set_hit_props(
            HitProps.new(
                user.damage,
                Hit.Impact | Hit.Flinch | Hit.Flash, 
                Element.None,
                user:get_id(), 
                Drag.None
            )
        )
	    spell:set_facing(facing)
        spell:set_palette(Engine.load_texture(_folderpath.."ratton_"..user.type..".palette.png"))
        spell.slide_started = false
	    local sprite = spell:sprite()
        sprite:set_texture(RATTON_TEXTURE, true)
	    sprite:set_layer(-3)
        local anim = spell:get_animation()
	    anim:load(RATTON_ANIMPATH)
        anim:set_state("0")
        anim:refresh(sprite)

        local speed = 8
        local cur_facing = facing
        local targetedU = false
        local targetedD = false
        local checkC = false
        local checkU1 = false
        local checkU2 = false
        local checkD1 = false
        local checkD2 = false
        local checkTHP = function(ent)
            if ent:get_team() ~= team and ent:get_health() > 0 then
                return true
            end
        end

	    spell.update_func = function(self)
            self:highlight_tile(Highlight.Solid)
            self:get_current_tile():attack_entities(self)
            if self:is_sliding() == false then
                local dest = self:get_tile(facing, 1)
                if not self:get_current_tile():is_walkable() and self.slide_started then
                    self:delete()
                end
                
                local destU1 = self:get_tile(Direction.Up, 1)
                local destU2 = self:get_tile(Direction.Up, 2)
                local destD1 = self:get_tile(Direction.Down, 1)
                local destD2 = self:get_tile(Direction.Down, 2)
                local ref = self
                if not targetedU and not targetedD then
                    if tile:y() == 1 then
                        local tileD1 = self:get_tile(Direction.Down, 1)
                        local tileD2 = self:get_tile(Direction.Down, 2)
                        checkD1 = #tileD1:find_characters(checkTHP) > 0
                        checkD2 = #tileD2:find_characters(checkTHP) > 0
                        if checkD1 or checkD2 then
                            targetedD = true
                        end
                    elseif tile:y() == 2 then
                        local tileC = self:get_current_tile()
                        local tileU1 = self:get_tile(Direction.Up, 1)
                        local tileD1 = self:get_tile(Direction.Down, 1)
                        checkC = #tileC:find_characters(checkTHP) > 0
                        checkU1 = #tileU1:find_characters(checkTHP) > 0
                        checkD1 = #tileD1:find_characters(checkTHP) > 0
                        if checkC then
                            targetedU = true
                            targetedD = true
                        end
                        if checkU1 then
                            targetedU = true
                        end
                        if checkD1 then
                            targetedD = true
                        end
                    elseif tile:y() == 3 then
                        local tileU1 = self:get_tile(Direction.Up, 1)
                        local tileU2 = self:get_tile(Direction.Up, 2)
                        checkU1 = #tileU1:find_characters(checkTHP) > 0
                        checkU2 = #tileU2:find_characters(checkTHP) > 0
                        if checkU1 or checkU2 then
                            targetedU = true
                        end
                    end
                end
                if targetedU and not targetedD then
                    dest = self:get_tile(Direction.Up, 1)
                    speed = 7
                    cur_facing = Direction.Up
                elseif not targetedU and targetedD then
                    dest = self:get_tile(Direction.Down, 1)
                    speed = 7
                    cur_facing = Direction.Down
                elseif targetedU and targetedD then
                    dest = self:get_tile(Direction.Down, 1)
                    speed = 7
                    cur_facing = Direction.Down
                end
                self:slide(dest, frames(user._slide_speed), frames(0), ActionOrder.Voluntary, function()
                    ref.slide_started = true
                end)
            end
        end
	    spell.collision_func = function(self, ent)
            local offset1 = 32
            local offset2 = 12
            local offset_x = nil
            local offset_y = nil
            if      cur_facing == Direction.Up then
                offset_x = 0
                offset_y = offset2 * 1
            elseif  cur_facing == Direction.Down then
                offset_x = 0
                offset_y = offset2 * -1
            elseif  cur_facing == Direction.Left then
                offset_x = offset1 * 1
                offset_y = 0
            elseif  cur_facing == Direction.Right then
                offset_x = offset1 * -1
                offset_y = 0
            end
            create_effect(facing, BOOM_TEXTURE, BOOM_ANIMPATH, "0", offset_x, offset_y, true, -999999, field, ent:get_current_tile())
            Engine.play_audio(BOOM_AUDIO, AudioPriority.Low)
            self:delete()
	    end
        spell.attack_func = function(self, ent)
            if Battle.Obstacle.from(ent) == nil then
                --[[
                if Battle.Player.from(user) ~= nil then
                    Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Low)
                end
                ]]
            else
                Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
            end
        end
	    spell.battle_end_func = function(self)
            create_effect(facing, BOOM_TEXTURE, BOOM_ANIMPATH, "0", 0, 0, true, -999999, field, ent:get_current_tile())
            Engine.play_audio(BOOM_AUDIO, AudioPriority.Low)
	    	self:delete()
	    end
	    spell.can_move_to_func = function(tile)
            return true
        end
        spell.delete_func = function(self)
            if not self:get_current_tile():is_walkable() then
                create_effect(facing, MOB_MOVE_TEXTURE, MOB_MOVE_ANIMPATH, "4", 0, 0, true, -9, field, self:get_current_tile())
            end
	    	self:erase()
        end
	    field:spawn(spell, tile)
    end
    spawn_next()
end

function create_effect(effect_facing, effect_texture, effect_animpath, effect_state, offset_x, offset_y, flip, offset_layer, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(effect_facing)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    hitfx:never_flip(flip)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(offset_layer)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end

return package_init