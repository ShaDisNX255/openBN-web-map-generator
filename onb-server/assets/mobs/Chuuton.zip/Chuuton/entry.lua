local shared_package_init = include("../shared/entry.lua")

function package_init(character)
    local character_info = {
        name = "Chuuton",
        hp = 40,
        damage = 20,
        palette = _folderpath.."battle_v1.palette.png",
        type = "v1",
        move_before_attack = 10,
        slide_speed = 20,
        angry_slide_speed = 10,
    }
    if character:get_rank() == Rank.V2 then
        character_info.hp = 80
        character_info.damage = 40
        character_info.palette = _folderpath.."battle_v2.palette.png"
        character_info.type = "v2"
        character_info.move_before_attack = 8
        character_info.slide_speed = 16
        character_info.angry_slide_speed = 8
    elseif character:get_rank() == Rank.V3 then
        character_info.hp = 130
        character_info.damage = 60
        character_info.palette = _folderpath.."battle_v3.palette.png"
        character_info.type = "v3"
        character_info.move_before_attack = 6
        character_info.slide_speed = 12
        character_info.angry_slide_speed = 6
    elseif character:get_rank() == Rank.SP then
        character_info.hp = 180
        character_info.damage = 80
        character_info.palette = _folderpath.."battle_sp.palette.png"
        character_info.type = "sp"
        character_info.move_before_attack = 4
        character_info.slide_speed = 8
        character_info.angry_slide_speed = 4
    end
    shared_package_init(character, character_info)
end
