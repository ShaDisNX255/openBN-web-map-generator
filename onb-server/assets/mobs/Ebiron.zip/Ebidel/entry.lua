local shared_package_init = include("../shared/entry.lua")

function package_init(character)
    local character_info = {
        name = "Ebidel",
        hp = 100,
        damage = 40,
        height = 44,
        frames_between_actions = 30,
        bubble_speed = 16,
        bounce_speed = 2,
        move_speed = 40,
        shot_type = 2,
        palette = _folderpath.."V2.png",
    }
    shared_package_init(character, character_info)
end
