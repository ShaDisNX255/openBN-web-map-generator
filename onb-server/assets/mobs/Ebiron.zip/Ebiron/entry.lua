local shared_package_init = include("../shared/entry.lua")

function package_init(character)
    local character_info = {
        name = "Ebiron",
        hp = 60,
        damage = 20,
        height = 44,
        frames_between_actions = 30,
        bubble_speed = 21,
        bounce_speed = 1,
        --move_speed = 28,
        move_speed = 50,
        shot_type = 1,
        palette = _folderpath.."V1.png",
    }
    if character:get_rank() == Rank.SP then
        character_info.hp = 220
        character_info.damage = 120
        character_info.bubble_speed = 8
        character_info.bounce_speed = 4
        character_info.move_speed = 20
        character_info.palette = _folderpath.."SP.png"
    end
    shared_package_init(character, character_info)
end
