local AUDIO_DAMAGE = Engine.load_audio(_folderpath.."EXE4_270.ogg")
local AUDIO_DAMAGE_OBS = Engine.load_audio(_folderpath.."EXE4_221.ogg")
local EFFECT_TEXTURE = Engine.load_texture(_folderpath.."effect.png")
local EFFECT_ANIMPATH = _folderpath.."effect.animation"

local CHARACTER_TEXTURE = Engine.load_texture(_folderpath.."battle.greyscaled.png")
local CHARACTER_ANIMATION = _folderpath.."battle.animation"
local BUBBLE_TEXTURE = Engine.load_texture(_folderpath.."bubble.png")
local BUBBLE_ANIMPATH = _folderpath.."bubble.animation"
local BUBBLE_CREATE_AUDIO = Engine.load_audio(_folderpath.."EXE4_139.ogg")
local BUBBLE_BOUNCE_AUDIO = Engine.load_audio(_folderpath.."EXE4_140.ogg")
local BUBBLES_TEXTURE = Engine.load_texture(_folderpath.."bubbles.png")
local BUBBLES_ANIMPATH = _folderpath.."bubbles.animation"
local BUBBLES_AUDIO = Engine.load_audio(_folderpath.."EXE4_119.ogg")

--possible states for character
local states = { IDLE = 1, MOVE = 2, WAIT = 3 }
local debug = false

function debug_print(str)
    if debug then
        print("[Ebiron] "..str)
    end
end

---@param self Entity
function package_init(self, character_info)
    -- Required function, main package information
    -- Load extra resources
    local base_animation_path = CHARACTER_ANIMATION
    self:set_texture(CHARACTER_TEXTURE)
    self.animation = self:get_animation()
    self.animation:load(base_animation_path)

    -- Set up character meta
    self:set_name(character_info.name)
    self:set_health(character_info.hp)
    self:set_height(character_info.height)
    self.damage = character_info.damage
    self:set_element(Element.Aqua)
    self:share_tile(false)
    self:set_explosion_behavior(3, 1, false)
    self:set_offset(0, 0)
    self:set_palette(Engine.load_texture(character_info.palette))
    self.bubble_speed = character_info.bubble_speed
    self.bounce_speed = character_info.bounce_speed
    self.shot_type = character_info.shot_type
    self.animation:set_state("SPAWN")
    self.frame_counter = 0
    self.started = false
    self.idle_frames = 8
    self.min_tiles = character_info.min_tiles
    self.max_tiles = character_info.max_tiles
    --Select bubble move direction
    self.move_direction = Direction.Up
    self.move_speed = character_info.move_speed
    self.reached_edge = false
    self.has_attacked_once = false

    --[[
    self.defense = Battle.DefenseVirusBody.new()
    self:add_defense_rule(self.defense)
    ]]

    self:set_air_shoe(true)
    self:set_float_shoe(true)

    ---state idle
    ---@param frame number
    self.action_idle = function(frame)
        if (frame == self.idle_frames) then
            ---choose move direction.
            self.animation:set_state("IDLE")
            self.animation:set_playback(Playback.Loop)
            self.set_state(states.MOVE)
        end
    end

    self.turn = function()
        debug_print("turned")
        self.move_direction = Direction.reverse(self.move_direction)
    end

    ---state move
    ---@param frame number
    self.action_move = function(frame)
        if (frame == 1) then
            -- get target to slide to
            local target_tile = self:get_tile(self.move_direction, 1)
            debug_print("Current tile "..Tiletostring(self:get_tile()))
            debug_print("Target = "..Tiletostring(target_tile))
            debug_print("Direction = "..directiontostring(self.move_direction))
            --if not free, change direction.
            if (not is_tile_free_for_movement(target_tile, self)) then
                self.turn()
                local turned_tile = self:get_tile(self.move_direction, 1)
                if (is_tile_free_for_movement(turned_tile, self)) then
                    --free to move to the turned tile, otherwise stuck.
                    self.set_state(states.MOVE)
                end
            end
            local wait_frames = 0
            local search_tile = self:get_tile(self.move_direction, 2)
            local check2 = search_tile:is_edge() or check_obstacles(search_tile, self)
            if search_tile ~= nil and check2 then
                wait_frames = 18
            else
                wait_frames = 0
            end
            self:slide(target_tile, frames(self.move_speed), frames(wait_frames), ActionOrder.Immediate, nil)
        end
        if (frame >= self.move_speed and not self:is_sliding()) then
            debug_print(tostring(self.wait_tiles))
            if (self.wait_tiles == 0) then
                -- once shrimpy has moved enough tiles, attack
                self.bubblespell()
                self.set_state(states.WAIT)
                self.wait_tiles = math.random(2, 4)
            else
                self.wait_tiles = self.wait_tiles - 1
                self.set_state(states.MOVE)
            end
        end
    end

    ---state wait
    ---@param frame number
    self.action_wait = function(frame)
        if (frame == 12) then
            self.set_state(states.IDLE)
        end
    end

    --utility to set the update state, and reset frame counter
    ---@param state number
    self.set_state = function(state)
        self.state = state
        self.frame_counter = 0
    end

    local actions = { [1] = self.action_idle, [2] = self.action_move, [3] = self.action_wait }

    self.update_func = function()
        self.frame_counter = self.frame_counter + 1
        if not self.started then
            --- this runs once the battle is started
            self.current_direction = self:get_facing()
            self.started = true
            self.set_state(states.IDLE)
            self.wait_tiles = math.random(2, 4)
        else
            --- On every frame, we will call the state action func.
            local action_func = actions[self.state]
            action_func(self.frame_counter)
        end
    end

    self.bubblespell = function()
        self.animation:set_state("ATTACK")
        self.has_attacked_once = true
        self.animation:on_frame(1, function()
            Engine.play_audio(BUBBLE_CREATE_AUDIO, AudioPriority.Low)
            local team = self:get_team()
            local field = self:get_field()
            local facing = self:get_facing()
            local tile = self:get_tile(facing, 1)
            spawn_bubble(self, Element.Aqua, self.damage, self.shot_type, team, facing, field, tile)
        end)
        self.animation:on_complete(function()
            self.set_state(states.WAIT)
        end)
    end

    function Tiletostring(tile)
        return "Tile: ["..tostring(tile:x())..","..tostring(tile:y()).."]"
    end

    function directiontostring(dir)
        if dir == Direction.Up then return "Up"
        elseif dir == Direction.Down then return "Down"
        end
    end
end

function spawn_bubble(user, element, damage, shot_type, team, facing, field, tile)
    local spell = Battle.Spell.new(team)
    local spell_animation = spell:get_animation()
    local sprite = spell:sprite()
    -- Spell Hit Properties
    spell:set_hit_props(
        HitProps.new(
            0,
            Hit.Impact,
            Element.None,
            user:get_id(),
            Drag.None
        )
    )
    spell:set_facing(facing)
    sprite:set_layer(-3)
    sprite:set_texture(BUBBLE_TEXTURE)
    spell_animation:load(BUBBLE_ANIMPATH)
    spell_animation:set_state("BUBBLESPAWN")
    spell_animation:refresh(sprite)
    --spell:set_shadow(Shadow.Small)
    for i = 1, 4, 1 do
        spell_animation:on_frame(i, function()
            spell:set_shadow(Engine.load_texture(_folderpath.."shadow"..i..".png"))
            if i == 4 then
                spell.moving = true
                spell.attacking = true
                spell_animation:set_state("BUBBLEBOUNCE")
                spell_animation:set_playback(Playback.Loop)
            end
        end)
    end
    spell:show_shadow(true)
    -- Starting direction is user's facing
    spell.moving = false
    spell.attacking = false
    spell.direction = facing
    spell.userfacing = facing
    spell.bubble_speed = user.bubble_speed
    spell.next_tile = tile:get_tile(spell.direction, 1)
    spell.frame_count = 0
    spell.elevation = 0
    local query_TeamHP = function(ent)
        if not user:is_team(ent:get_team()) and ent:get_health() > 0 then
            return true
        end
    end
    spell.update_func = function(self, dt)
        local self_tile = self:get_current_tile()
        local ref = self
        if      element == Element.Fire then
            if self_tile ~= nil and
                not self_tile:is_edge() and
                #self_tile:find_characters(query_TeamHP) <= 0 and 
                #self_tile:find_obstacles(query_TeamHP) <= 0 and 
                self_tile:get_state() == TileState.Grass
                then
                self_tile:set_state(TileState.Normal)
            end
        elseif  element == Element.Aqua then
            if self_tile ~= nil and
                not self_tile:is_edge() and
                #self_tile:find_characters(query_TeamHP) <= 0 and 
                #self_tile:find_obstacles(query_TeamHP) <= 0 and 
                self_tile:get_state() == TileState.Lava
                then
                self_tile:set_state(TileState.Normal)
            end
        end
        if ref.attacking then
            self:get_current_tile():attack_entities(self)
        end
        if self.moving then
            if self.next_tile == nil or self:get_current_tile():is_hole() then
                self:delete()
            end

            if user.bounce_speed == 2 then
                if spell.frame_count < 1 then
                    spell.elevation = spell.elevation + 6
                elseif spell.frame_count < 2 then
                    spell.elevation = spell.elevation + 5
                elseif spell.frame_count < 3 then
                    spell.elevation = spell.elevation + 5
                elseif spell.frame_count < 4 then
                    spell.elevation = spell.elevation + 4
                elseif spell.frame_count < 5 then
                    spell.elevation = spell.elevation + 3
                elseif spell.frame_count < 6 then
                    spell.elevation = spell.elevation + 3
                elseif spell.frame_count < 7 then
                    spell.elevation = spell.elevation + 2
                elseif spell.frame_count < 8 then
                    spell.elevation = spell.elevation + 2
                elseif spell.frame_count < 9 then
                    spell.elevation = spell.elevation - 2
                elseif spell.frame_count < 10 then
                    spell.elevation = spell.elevation - 2
                elseif spell.frame_count < 11 then
                    spell.elevation = spell.elevation - 3
                elseif spell.frame_count < 12 then
                    spell.elevation = spell.elevation - 3
                elseif spell.frame_count < 13 then
                    spell.elevation = spell.elevation - 4
                elseif spell.frame_count < 14 then
                    spell.elevation = spell.elevation - 5
                elseif spell.frame_count < 15 then
                    spell.elevation = spell.elevation - 5
                elseif spell.frame_count < 16 then
                    spell.elevation = spell.elevation - 6
                else
                    spell.elevation = 0
                    spell.frame_count = 0
                end
            elseif user.bounce_speed == 3 then
                if spell.frame_count < 1 then
                    spell.elevation = spell.elevation + 8
                elseif spell.frame_count < 2 then
                    spell.elevation = spell.elevation + 6
                elseif spell.frame_count < 3 then
                    spell.elevation = spell.elevation + 6
                elseif spell.frame_count < 4 then
                    spell.elevation = spell.elevation + 4
                elseif spell.frame_count < 5 then
                    spell.elevation = spell.elevation + 3
                elseif spell.frame_count < 6 then
                    spell.elevation = spell.elevation + 3
                elseif spell.frame_count < 7 then
                    spell.elevation = spell.elevation - 3
                elseif spell.frame_count < 8 then
                    spell.elevation = spell.elevation - 3
                elseif spell.frame_count < 9 then
                    spell.elevation = spell.elevation - 4
                elseif spell.frame_count < 10 then
                    spell.elevation = spell.elevation - 6
                elseif spell.frame_count < 11 then
                    spell.elevation = spell.elevation - 6
                elseif spell.frame_count < 12 then
                    spell.elevation = spell.elevation - 8
                else
                    spell.elevation = 0
                    spell.frame_count = 0
                end
            elseif user.bounce_speed == 4 then
                if spell.frame_count < 1 then
                    spell.elevation = spell.elevation + 12
                elseif spell.frame_count < 2 then
                    spell.elevation = spell.elevation + 9
                elseif spell.frame_count < 3 then
                    spell.elevation = spell.elevation + 6
                elseif spell.frame_count < 4 then
                    spell.elevation = spell.elevation + 3
                elseif spell.frame_count < 5 then
                    spell.elevation = spell.elevation - 3
                elseif spell.frame_count < 6 then
                    spell.elevation = spell.elevation - 6
                elseif spell.frame_count < 7 then
                    spell.elevation = spell.elevation - 9
                elseif spell.frame_count < 8 then
                    spell.elevation = spell.elevation - 12
                else
                    spell.elevation = 0
                    spell.frame_count = 0
                end
                --[[
                if spell.frame_count < 1 then
                    spell.elevation = spell.elevation + 10
                elseif spell.frame_count < 2 then
                    spell.elevation = spell.elevation + 8
                elseif spell.frame_count < 3 then
                    spell.elevation = spell.elevation + 6
                elseif spell.frame_count < 4 then
                    spell.elevation = spell.elevation + 4
                elseif spell.frame_count < 5 then
                    spell.elevation = spell.elevation + 2
                elseif spell.frame_count < 6 then
                    spell.elevation = spell.elevation - 2
                elseif spell.frame_count < 7 then
                    spell.elevation = spell.elevation - 4
                elseif spell.frame_count < 8 then
                    spell.elevation = spell.elevation - 6
                elseif spell.frame_count < 9 then
                    spell.elevation = spell.elevation - 8
                elseif spell.frame_count < 10 then
                    spell.elevation = spell.elevation - 10
                else
                    spell.elevation = 0
                    spell.frame_count = 0
                end
                ]]
            else
                if spell.frame_count < 2 then
                    spell.elevation = spell.elevation + 5
                elseif spell.frame_count < 4 then
                    spell.elevation = spell.elevation + 4
                elseif spell.frame_count < 6 then
                    spell.elevation = spell.elevation + 3
                elseif spell.frame_count < 8 then
                    spell.elevation = spell.elevation + 2
                elseif spell.frame_count < 10 then
                    spell.elevation = spell.elevation + 1
                elseif spell.frame_count < 12 then
                    spell.elevation = spell.elevation - 1
                elseif spell.frame_count < 14 then
                    spell.elevation = spell.elevation - 2
                elseif spell.frame_count < 16 then
                    spell.elevation = spell.elevation - 3
                elseif spell.frame_count < 18 then
                    spell.elevation = spell.elevation - 4
                elseif spell.frame_count < 20 then
                    spell.elevation = spell.elevation - 5
                else
                    spell.elevation = 0
                    spell.frame_count = 0
                end
            end
            self:set_elevation(spell.elevation)
            self:slide(spell.next_tile, frames(spell.bubble_speed), frames(0), ActionOrder.Voluntary, function()
                Engine.play_audio(BUBBLE_BOUNCE_AUDIO, AudioPriority.Low)
            end)
            self.next_tile = self:get_current_tile():get_tile(spell.direction, 1)

            self.frame_count = spell.frame_count + 1
        end
    end

    spell.attack_func = function(self, ent)
        create_attack2(user, element, damage, shot_type, team, facing, field, ent:get_current_tile())													        --current tile
		if 		shot_type == 1 then
			create_attack2(user, element, damage, shot_type, team, facing, field, ent:get_tile(facing, 1))													    --forward
		elseif	shot_type == 2 then
			create_attack2(user, element, damage, shot_type, team, facing, field, ent:get_tile(Direction.join(Direction.Up, facing), 1))						--up-forward
			create_attack2(user, element, damage, shot_type, team, facing, field, ent:get_tile(Direction.join(Direction.Down, facing), 1))					    --down-forward
		elseif	shot_type == 3 then
			create_attack2(user, element, damage, shot_type, team, facing, field, ent:get_tile(Direction.Up, 1))												--up
			create_attack2(user, element, damage, shot_type, team, facing, field, ent:get_tile(Direction.Down, 1))											    --down
		else
			create_attack2(user, element, damage, shot_type, team, facing, field, ent:get_tile(facing, 1))													    --forward
			create_attack2(user, element, damage, shot_type, team, facing, field, ent:get_tile(Direction.Up, 1))												--up
			create_attack2(user, element, damage, shot_type, team, facing, field, ent:get_tile(Direction.Down, 1))											    --down
			create_attack2(user, element, damage, shot_type, team, facing, field, ent:get_tile(Direction.reverse(facing), 1))									--back
			create_attack2(user, element, damage, shot_type, team, facing, field, ent:get_tile(Direction.join(Direction.Up, facing), 1))						--up-forward
			create_attack2(user, element, damage, shot_type, team, facing, field, ent:get_tile(Direction.join(Direction.Down, facing), 1))					    --down-forward
			create_attack2(user, element, damage, shot_type, team, facing, field, ent:get_tile(Direction.join(Direction.Up, Direction.reverse(facing)), 1))	    --up-back
			create_attack2(user, element, damage, shot_type, team, facing, field, ent:get_tile(Direction.join(Direction.Down, Direction.reverse(facing)), 1))	--down-back
		end
    end
    spell.collision_func = function(self, ent)
        if self.attacking then
            self:delete()
        end
    end
    spell.delete_func = function(self)
        self:erase()
    end
    spell.can_move_to_func = function(tile)
        return true
    end
    field:spawn(spell, tile)
end

function create_attack2(user, element, damage, shot_type, team, facing, field, tile)
    local spawn
    spawn = function()
        if tile == nil or tile:is_edge() then return end

    	local spell = Battle.Spell.new(team)
    	spell:set_facing(facing)
    	spell:set_hit_props(
    	    HitProps.new(
    	        damage, 
    	        Hit.Impact | Hit.Flinch | Hit.Flash, 
    	        element,
    	        user:get_id(), 
    	        Drag.None
    	    )
    	)
		local anim = spell:get_animation()
		anim:load(_folderpath.."testdot.animation")
		anim:set_state("0")
		anim:on_complete(function() spell:delete() end)
		local query_TeamHP = function(ent)
            if not user:is_team(ent:get_team()) and ent:get_health() > 0 then
                return true
            end
        end
    	spell.update_func = function(self)
            local self_tile = self:get_current_tile()
            self_tile:attack_entities(self)
			if 		element == Element.Aqua then
				if self_tile ~= nil and
					not self_tile:is_edge() and
					#self_tile:find_characters(query_TeamHP) <= 0 and 
					#self_tile:find_obstacles(query_TeamHP) <= 0 and 
					self_tile:get_state() == TileState.Lava
					then
					self_tile:set_state(TileState.Normal)
				end
			elseif	element == Element.Fire then
				if self_tile ~= nil and
					not self_tile:is_edge() and
					#self_tile:find_characters(query_TeamHP) <= 0 and 
					#self_tile:find_obstacles(query_TeamHP) <= 0 and 
					self_tile:get_state() == TileState.Grass
					then
					self_tile:set_state(TileState.Normal)
				end
			end
    	end
		spell.attack_func = function(self, ent)
			if Battle.Obstacle.from(ent) == nil then
                --[[
				if Battle.Player.from(user) ~= nil then
					Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Low)
				end
                ]]
			else
				Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
			end
		end
		spell.battle_end_func = function(self)
			spell:delete()
		end
		spell.can_move_to_func = function(tile)
			return true
		end
		spell.delete_func = function(self)
			spell:erase()
		end
		if 		element == Element.Aqua then
			Engine.play_audio(BUBBLES_AUDIO, AudioPriority.Low)
			create_effect(facing, BUBBLES_TEXTURE, BUBBLES_ANIMPATH, "0", 0, 0, false, -9, field, tile)
		elseif 	element == Element.Fire then
			Engine.play_audio(HEAT_AUDIO, AudioPriority.Low)
			create_effect(facing, HEAT_TEXTURE, HEAT_ANIMPATH, "0", 0, 0, false, -9, field, tile)
		else
			create_effect(facing, BURST_TEXTURE, BURST_ANIMPATH, "0", 0, 0, false, -9, field, tile)
		end
		field:spawn(spell, tile)
	end
    spawn()
end

--Function by Alrysc
function check_obstacles(tile, self)
    local ob = tile:find_obstacles(function(o)
        return o:get_health() > 0 
    end)

    return #ob > 0 
end

---Checks if the tile in 2 given directions is free and returns that direction
function get_free_direction(tile, direction1, direction2)
    if (not tile:get_tile(direction1, 1):is_edge()) then
        return direction1
    else return direction2

    end
end

function is_tile_free_for_movement(tile, character)
    --Basic check to see if a tile is suitable for a chracter of a team to move to

    if tile:get_team() ~= character:get_team() or tile:is_reserved({ character:get_id(), character._reserver }) then
        return false
    end
    if (tile:is_edge()) then
        return false
    end
    local occupants = tile:find_entities(function(ent)
        if (Battle.Character.from(ent) ~= nil or Battle.Obstacle.from(ent) ~= nil) then
            return true
        else
            return false
        end
    end)
    if #occupants == 1 and occupants[1]:get_id() == character:get_id() then
        return true
    end
    if #occupants > 0 then
        return false
    end

    return true
end

function create_effect(effect_facing, effect_texture, effect_animpath, effect_state, offset_x, offset_y, flip, offset_layer, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(effect_facing)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    hitfx:never_flip(flip)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(offset_layer)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end

return package_init
