local shared_package_init = include("../shared/entry.lua")

function package_init(character)
    local character_info = {
        name = "EbiSide",
        hp = 140,
        damage = 70,
        height = 44,
        frames_between_actions = 30,
        bubble_speed = 11,
        bounce_speed = 3,
        move_speed = 30,
        shot_type = 3,
        palette = _folderpath.."V3.png",
    }
    shared_package_init(character, character_info)
end
