local shared_package_init = include("../CirKiller/character.lua")

function package_init(character)
    local character_info = {
        name = "CirKiller",
        name_on_spawn = true,
        health = 110,
        damage = 30,
        height = 44,
        element = Element.None,
        damage_roundshot = 30,
        bullet_speed = 20,
        move_speed = 23,
        move_speed2 = 44,
        clockwise = false,
    }
    if character:get_rank() == Rank.V2 then
        character_info.name = "CirKllrEX"
        character_info.health = 140
        character_info.damage = 60
        character_info.damage_roundshot = 60
        character_info.bullet_speed = 20
        character_info.move_speed = 23
        character_info.move_speed2 = 44
        character_info.clockwise = true
    elseif character:get_rank() == Rank.V3 then
        character_info.name = "CirKilire"
        character_info.health = 180
        character_info.damage = 90
        character_info.damage_roundshot = 90
        character_info.bullet_speed = 16
        character_info.move_speed = 19
        character_info.move_speed2 = 34
    elseif character:get_rank() == Rank.SP then
        character_info.name = "CirKlreEX"
        character_info.health = 220
        character_info.damage = 120
        character_info.damage_roundshot = 130
        character_info.bullet_speed = 16
        character_info.move_speed = 19
        character_info.move_speed2 = 34
        character_info.clockwise = true
    elseif character:get_rank() == Rank.Rare1 then
        character_info.name = "CirKiland"
        character_info.health = 260
        character_info.damage = 150
        character_info.damage_roundshot = 180
        character_info.bullet_speed = 13
        character_info.move_speed = 16
        character_info.move_speed2 = 28
    elseif character:get_rank() == Rank.Rare2 then
        character_info.name = "CirKlndEX"
        character_info.health = 300
        character_info.damage = 200
        character_info.damage_roundshot = 250
        character_info.bullet_speed = 13
        character_info.move_speed = 16
        character_info.move_speed2 = 28
        character_info.clockwise = true
    else
        character_info.name_on_spawn = false
    end
    shared_package_init(character,character_info)
end
