local status = {}
local status_name = "WIND_PUSH"
--[[
    I'm using Team.Blue to tell the component to delete itself, and 
    Team.Red to tell it to reset time
]]

local function apply_func(artifact, other, dir)
    -- Incremet for each frame is_moving is false, decrement 
    -- if move begins. If it reaches 2, eject, because they probably 
    -- couldn't be moved.
    local consecutive_movable_frames = 0

    local component = Battle.Component.new(other, Lifetimes.Battlestep)

    component.update_func = function()
        if artifact:get_team() == Team.Red then
            artifact:set_team(Team.Other)
        elseif artifact:get_team() == Team.Blue then 
            artifact:delete()
            component:eject()
            return
        end

        if other:is_dragged() then 
            component:eject()
            artifact:delete()
            return
        end

        if other:is_moving() then return end
        consecutive_movable_frames = consecutive_movable_frames + 1
        -- Despite trying to move last frame, we aren't moving yet. Assume
        -- something prevents movement, such as a CardAction, and give up.
        if consecutive_movable_frames >= 2 then 
            component:eject()
            artifact:delete()
            return
        end

        -- print("Going to slide")
        local cur_tile = other:get_current_tile()
        --print("Cur tile is ", start_tile:x(), start_tile:y())

        local move = MoveEvent.new() 
            move.delta_frames = frames(4)
            move.delay_frames = frames(0)
            move.endlag_frames = frames(0)
            move.height = 0
            move.dest_tile = cur_tile:get_tile(dir, 1)
            move.on_begin_func = function() 
                consecutive_movable_frames = 0
            end

        if not other:raw_move_event(move, ActionOrder.Immediate) then 
            component:eject()
            artifact:delete()
        end
    end
    
    other:register_component(component)
end

status.apply = function(recipient, dir)
    if status.is_immune(recipient) then return false end
    local existing_artifact = status.has_status(recipient, true)
    if existing_artifact ~= nil and existing_artifact ~= false then 
        return existing_artifact
    end
        
    local f = recipient:get_field()
    local artifact = Battle.Artifact.new()
    artifact:set_name("STATUS_HANDLE_"..status_name..recipient:get_id())
    f:spawn(artifact, 0, 0)

    apply_func(artifact, recipient, dir)
    f:notify_on_delete(recipient:get_id(), artifact:get_id(), function()
        artifact:set_team(Team.Blue)
    end)

    return artifact
end


status.has_status = function(entity, should_return_object)
    local e = entity:get_field():tile_at(0, 0):find_entities(function(ent)
        return not ent:is_deleted() and ent:get_name() == "STATUS_HANDLE_"..status_name..entity:get_id()
    end)

    
    if #e > 0 then 
        if should_return_object then 
            return e[1]
        end

        return true
    end

    return false
end

status.is_immune = function(entity)
    local e = entity:get_field():tile_at(1, 0):find_entities(function(ent)
        return not ent:is_deleted() and ent:get_name() == "STATUS_IMMUNITY_"..status_name..entity:get_id()
    end)

    
    if #e > 0 then 
        return true
    end

    return false
end

status.make_entity_immune_to_status = function(entity)
    local f = entity:get_field()

    local artifact = Battle.Artifact.new()
    artifact:set_name("STATUS_IMMUNITY_"..status_name..entity:get_id())
    f:spawn(artifact, 1, 0)

    f:notify_on_delete(entity:get_id(), artifact:get_id(), function()
        artifact:delete()
    end)
end

status.remove_immunity = function(entity)
    local e = entity:get_field():tile_at(1, 0):find_entities(function(ent)
        return not ent:is_deleted() and ent:get_name() == "STATUS_IMMUNITY_"..status_name..entity:get_id()
    end)

    
    if e[1] then 
        e[1]:delete()
        return true
    end

    return false
end

return status