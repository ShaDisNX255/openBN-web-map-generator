local print_debug = false

local CHARACTER_TEXTURE = Engine.load_texture(_folderpath.."gfx/battle.grayscaled.png")
local CHARACTER_ANIMPATH = _folderpath.."gfx/battle.animation"

local ROUNDSHOT_TEXTURE = Engine.load_texture(_folderpath.."gfx/roundshot.grayscaled.png")
local ROUNDSHOT_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/roundshot.png")
local ROUNDSHOT_ANIMPATH = _folderpath.."gfx/roundshot.animation"
local SHOOT_FX_TEXTURE = Engine.load_texture(_folderpath.."gfx/shoot_fx.grayscaled.png")
local SHOOT_FX_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/shoot_fx.png")
local SHOOT_FX_ANIMPATH = _folderpath.."gfx/shoot_fx.animation"
local EFFECT_TEXTURE = Engine.load_texture(_folderpath.."gfx/effect.grayscaled.png")
local EFFECT_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/effect.png")
local EFFECT_ANIMPATH = _folderpath.."gfx/effect.animation"

local ROUNDSHOT_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE4_340.ogg")

local battle_helpers = include("libs/battle_helpers.lua")
local WindPush = include("libs/WindPush.lua")

function debug_print(str)
    if print_debug then
        print("[CirKiller] "..str)
    end
end

--possible states for character
local states = { DEFAULT = 1, REVERSE = 2 }

--(Function by Alrysc, edited by K1rbYat1Na)
local function graphic_init(type, x, y, texture, palette, animation, layer, state, anim_playback, user, facing, delete_on_complete, relative_to_user, flip)
    texture = texture or nil
    animation = animation or nil
    layer = layer or nil
    state = state or nil
    anim_playback = anim_playback or nil
    facing = facing or nil
    delete_on_complete = delete_on_complete or false
    flip = flip or false
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(user:get_team())
    end
    if palette then
        graphic:store_base_palette(palette)
        graphic:set_palette(graphic:get_base_palette())
    end
    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then 
        graphic:set_facing(facing)
    end
    
    if relative_to_user and user:get_facing() == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end

local function move_slide(self, direction, frames1, frames2)
    self.slide_component = Battle.Component.new(self, Lifetimes.Battlestep)
    local cur_tile = 1
    local self_tile = self:get_tile()
    local tileWidthO = self_tile:width()
    local tileHeightO = self_tile:height()
    local tileWidth = tileWidthO/2
    local tileHeight = tileHeightO/2 - tileHeightO/10
    local offset_x = self:get_offset().x
    local offset_y = self:get_offset().y
    local round = function(val)
        if facing == Direction.Right then
            return math.floor(val)
        else
            return math.ceil(val)
        end
    end
    self.slide_component.update_func = function()
        if self:is_bubbled() then
            self.slide_component:eject()
            self.slide_component = nil
            self:set_offset(0,0)
            return
        end
        if self:is_stunned() or self:is_frozen() or self.is_deleting then return end
        ----
        local frames = frames1
        if self:is_confused() or self:is_blind() then
            frames = frames2
        end
        local round_x = 0
        local round_y = 0
        if direction == Direction.Up then
            offset_y = offset_y - tileHeightO/frames
            round_y = round(offset_y)
            if round_y < 0 and cur_tile == 2 then
                round_y = 0
                cur_tile = 3
            end
            if round_y < -tileHeight and cur_tile == 1 then
                self:teleport(self:get_tile(Direction.Up,1), ActionOrder.Immediate)
                round_y = (tileHeight+(round_y+tileHeight))
                offset_y = round_y
                cur_tile = 2
            end
        elseif direction == Direction.Down then
            offset_y = offset_y + tileHeightO/frames
            round_y = round(offset_y)
            if round_y > 0 and cur_tile == 2 then
                round_y = 0
                cur_tile = 3
            end
            if round_y > tileHeight and cur_tile == 1 then
                self:teleport(self:get_tile(Direction.Down,1), ActionOrder.Immediate)
                round_y = -(tileHeight-(round_y-tileHeight))
                offset_y = round_y
                cur_tile = 2
            end
        elseif direction == Direction.Left then
            offset_x = offset_x - tileWidthO/frames
            round_x = round(offset_x)
            if round_x < 0 and cur_tile == 2 then
                round_x = 0
                cur_tile = 3
            end
            if round_x < -tileWidth and cur_tile == 1 then
                self:teleport(self:get_tile(Direction.Left,1), ActionOrder.Immediate)
                round_x = (tileWidth+(round_x+tileWidth))
                offset_x = round_x
                cur_tile = 2
            end
        elseif direction == Direction.Right then
            offset_x = offset_x + tileWidthO/frames
            round_x = round(offset_x)
            if round_x > 0 and cur_tile == 2 then
                round_x = 0
                cur_tile = 3
            end
            if round_x > tileWidth and cur_tile == 1 then
                self:teleport(self:get_tile(Direction.Right,1), ActionOrder.Immediate)
                round_x = -(tileWidth-(round_x-tileWidth))
                offset_x = round_x
                cur_tile = 2
            end
        end
        self:set_offset(round_x,round_y)
        if cur_tile >= 3 then
            self.slide_component:eject()
            self.slide_component = nil
            self:set_offset(0,0)
        end
    end
    self:register_component(self.slide_component)
end

-- Load character resources
---@param self Entity
function package_init(self, character_info)
    -- Required function, main package information
    self.texture = CHARACTER_TEXTURE
    self.animation = self:get_animation()
    self.animation:load(CHARACTER_ANIMPATH)
    -- Load extra resources
    -- Set up character meta
    -- Common Properties
    self:set_name(character_info.name)
    self:set_health(character_info.health)
    self:set_element(character_info.element)
    self:set_texture(self.texture, true)
    self:set_height(40)
    self:share_tile(false)
    self:set_explosion_behavior(2, 1, false)
    self:set_offset(0,0)
    self:set_palette(Engine.load_texture(_folderpath.."gfx/palette/battle-"..self:get_rank()..".png"))
    self.damage = character_info.damage
    -- CirKiller Specific
    self.damage_roundshot = character_info.damage_roundshot
    self.bullet_speed = character_info.bullet_speed
    self.move_speed = character_info.move_speed
    self.move_speed2 = character_info.move_speed2
    self.clockwise = character_info.clockwise
    -- Other Setup
    self.cooldown_amount = 54
    self.stuck_time = -1
    self.try_reverse = false
    -- entity will spawn with this animation.
    self.animation:set_state("SPAWN")
    --self.animation:refresh(self:sprite())
    self.frame_counter = 0
    self.started = false
    self.is_deleting = false
    -- This defense rule is added to prevent enemy from gaining invincibility after taking damage.
    self.defense = Battle.DefenseVirusBody.new()
    self:add_defense_rule(self.defense)
    -- Can't be Drages
    self.defense_rule = Battle.DefenseRule.new(0, DefenseOrder.CollisionOnly)
    self.defense_rule.filter_statuses_func = function(statuses)
		statuses.flags = statuses.flags & ~Hit.Drag
		return statuses
	end
    self:add_defense_rule(self.defense_rule)

    self.move_counter = 0
    self.cooldown_frames = 0

    local ref = self
    self.counterable_component = Battle.Component.new(self, Lifetimes.Battlestep)
    self.counterable_component.timer = 0
    self.counterable_component.update_func = function(self)
        if self.timer > 0 then
            debug_print("COUNTERABLE")
            self.timer = self.timer - 1
            ref:toggle_counter(true)
        else
            ref:toggle_counter(false)
        end
    end
    self:register_component(self.counterable_component)
    self.hit_func = function(from_stun)
        debug_print("Hit func runs")
        self.counterable_component.timer = 0
        self:toggle_counter(false)
    end
    self.on_countered = function(self)
        debug_print("Countered")
        self.hit_func(true)
    end
    self:register_status_callback(Hit.Stun, function() self.hit_func(true) end)
    self:register_status_callback(Hit.Freeze, function() self.hit_func(true) end)
    self.slide_component = nil

    -- actions for states
    -- Code that runs in the default state
    ---@param frame number
    self.action_default = function(frame)
        if frame == 1 then
            local target_dir = nil
            local target_tile = nil
            if self.try_reverse then
                self.try_reverse = false
                target_dir = getNextTile(self, true)
            else
                target_dir = getNextTile(self)
            end
            if target_dir == "STUCK" then
                --self.is_stuck = true
                if self.stuck_time == -1 then
                    --print("set stuck timer for "..self:get_id())
                    self.stuck_time = 180
                elseif self.stuck_time == 0 then
                    self.try_reverse = true
                end
                return
            elseif target_dir == "NONE" then
                --self.set_state(states.REVERSE)
                --self.rev_dir = Direction.reverse(self.current_dir)
                return
            else
                self.stuck_time = -1
            end
            target_tile = self:get_tile(target_dir,1)
            --[[
            if not self:is_confused() and not self:is_blind() then
                self:slide(target_tile, frames(self.move_speed), frames(0), ActionOrder.Immediate)
            else
                self:slide(target_tile, frames(self.move_speed2), frames(0), ActionOrder.Immediate)
            end]]
            target_tile:reserve_entity_by_id(self:get_id())
            move_slide(self, target_dir, self.move_speed, self.move_speed2)
        end
        if self:is_rooted() then return end
        if frame >= self.move_speed and not self.slide_component then
            self.set_state(states.DEFAULT)
        end
        self.do_attack()
    end

    self.action_reverse = function(frame)
        if frame == 1 then
            target_tile = self:get_tile(self.rev_dir, 1)
            if not battle_helpers.can_move_to_func(target_tile, self) then
                self.set_state(states.DEFAULT)
                return
            end
            if not self:is_confused() and not self:is_blind() then
                self:slide(target_tile, frames(self.move_speed), frames(0), ActionOrder.Immediate)
            else
                self:slide(target_tile, frames(self.move_speed2), frames(0), ActionOrder.Immediate)
            end
        end
        if self:is_rooted() then return end
        if frame >= self.move_speed and not self:is_sliding() then
            self.set_state(states.REVERSE)
        end
        self.do_attack()
    end

    self.do_attack = function()
        if self.cooldown_frames > 0 then
            return
        end
        local targ = battle_helpers.find_target(self)
        if not targ then return end
        if targ:get_tile():y() == self:get_tile():y() and not self:is_confused() and not self:is_blind() then
            self.animation:set_state("ATTACK")
            --self.animation:refresh(self:sprite())
            Engine.play_audio(ROUNDSHOT_AUDIO, AudioPriority.Immediate)
            self.animation:on_frame(1, function()
                self.counterable_component.timer = 12 -- Makes the Character counterable for 12 frames.
                create_shot(self, self:get_tile(self:get_facing(), 1), self.damage_roundshot, self.bullet_speed, self:get_facing())
                self.cooldown_frames = self.cooldown_amount
            end)
            self.animation:on_complete(function()
                self.animation:set_state("PLAYER_IDLE")
                --self.animation:refresh(self:sprite())
                self.animation:set_playback(Playback.Loop)
            end)
        end
    end

    --utility to set the update state, and reset frame counter
    ---@param state number
    self.set_state = function(state)
        self.state = state
        self.frame_counter = 0
    end
    local actions = { [1] = self.action_default, [2] = self.action_reverse }
    self.on_spawn_func = function(self)
        debug_print("on_spawn_func called")
        if character_info.name_on_spawn then
            self:set_name(character_info.name)
        end
        WindPush.make_entity_immune_to_status(self)
    end
    self.delete_func = function()
        self.is_deleting = true
    end
    self.update_func = function()
        self.frame_counter = self.frame_counter + 1
        if not self.started then
            self.started = true
            self.set_state(states.DEFAULT)
            self.animation:set_state("PLAYER_IDLE")
            self.animation:set_playback(Playback.Loop)
            --self.animation:refresh(self:sprite())
            local start_tile = self:get_tile()
            --[[
            if (start_tile:y() == 1) then
                self.current_dir = self:get_facing_away()
            else
                self.current_dir = self:get_facing()
            end
            if (self:get_facing() == Direction.Right) then
                self.current_dir = Direction.reverse(self.current_dir)
            end]]
            self.current_dir = Direction.Down
        else
            local action_func = actions[self.state]
            action_func(self.frame_counter)
            if self.cooldown_frames > 0 then
                self.cooldown_frames = self.cooldown_frames - 1
            end
            if self.stuck_time > 0 then
                --print(self:get_id().." stuck timer: "..self.stuck_time)
                self.stuck_time = self.stuck_time - 1
            end
        end
    end
end

-- Can change direction multiple times in a row.
---@param clockwise boolean whether clockwise or not.
---@return number
function getNextDirection(user, direction, clockwise)
    local dir_array = {user:get_facing(), Direction.Up, user:get_facing_away(), Direction.Down, user:get_facing(), Direction.Up}
    local dir = 1
    if (direction == Direction.Up) then
        dir = 2
    elseif (direction == user:get_facing_away()) then
        dir = 3
    elseif (direction == Direction.Down) then
        dir = 4
    elseif (direction == user:get_facing()) then
        dir = 5
    end
    if clockwise then
        --print("dir: "..dir-1)
        return dir_array[dir-1]
    else
        --print("dir: "..dir+1)
    end
    return dir_array[dir+1]
end

function print_dir(dir)
    if dir == Direction.Right then
        print("right")
    elseif dir == Direction.Left then
        print("left")
    elseif dir == Direction.Down then
        print("down")
    elseif dir == Direction.Up then
        print("up")
    else
        print("none")
    end
end

function getNextTile(user, ignore_charas)
    local tile = user:get_tile()
    local target_movement_tile = "NONE"
    local prospective_tiles = {}
    local prospective_dirs = {}
    -- cardinal directions
    local clockwise = user.clockwise
    local new_direction_1 = getNextDirection(user, user.current_dir, clockwise)
    local new_direction_2 = getNextDirection(user, new_direction_1,  clockwise)
    local new_direction_3 = getNextDirection(user, new_direction_2,  clockwise)
    table.insert(prospective_tiles, user:get_tile(user.current_dir, 1))
    table.insert(prospective_tiles, user:get_tile(new_direction_1,  1))
    table.insert(prospective_tiles, user:get_tile(new_direction_2,  1))
    table.insert(prospective_tiles, user:get_tile(new_direction_3,  1))
    table.insert(prospective_dirs, user.current_dir)
    table.insert(prospective_dirs, new_direction_1)
    table.insert(prospective_dirs, new_direction_2)
    table.insert(prospective_dirs, new_direction_3)
    --[[
    print("dirs ARE...")
    for i=1,#prospective_dirs do
        print_dir(prospective_dirs[i])
    end]]
    for index, tile in ipairs(prospective_tiles) do
        if is_tile_free_for_movement(tile, user) and not check_characters_true_team(tile, user) and not tile:is_reserved({user:get_id(), user._reserver}) then
            if index ~= 1 then
                --print_dir(prospective_dirs[index])
                user.current_dir = prospective_dirs[index]
            end
            return prospective_dirs[index]
        else
            if check_characters_true_team(tile, user) or tile:is_reserved({user:get_id(), user._reserver}) then
                --user.current_dir = prospective_dirs[index]
                target_movement_tile = "STUCK"
                if not ignore_charas then
                    return target_movement_tile
                end
            elseif not is_tile_free_for_movement(tile, user) then
                target_movement_tile = "NONE"
                --return target_movement_tile
            end
        end
    end
    return target_movement_tile
end

function is_tile_free_for_movement(tile, user)
    --Basic check to see if a tile is suitable for a chracter of a team to move to
    if tile:get_team() ~= user:get_team() then
        return false
    end
    if (tile:is_edge() or not tile:is_walkable()) then
        return false
    end
    --[[
    local occupants = tile:find_entities(function(ent)
        if (ent:get_health() <= 0) then
            return false
        end
        if (Battle.Character.from(ent) ~= nil or Battle.Obstacle.from(ent) ~= nil) then
            return true
        else
            return false
        end
    end)
    if #occupants == 1 and occupants[1]:get_id() == user:get_id() then
        return true
    end
    if #occupants > 0 then
        return false
    end]]
    return not check_obstacles(tile)
end

---@param user Entity The user summoning a shot
---@param tile Tile The tile to summon the shot on
---@param damage number The amount of damage the shot will do
---@param speed number The number of frames it takes the shot to travel 1 tile.
---@param facing any The facing the
function create_shot(user, tile, damage, speed, facing)
    if not tile then return end
    -- Creates a new spell that belongs to the user's team using graphic_init.
    local shoot_fx = graphic_init("artifact", 32*2, 0, SHOOT_FX_TEXTURE, SHOOT_FX_PALETTE, SHOOT_FX_ANIMPATH, -99, "0", Playback.Once, user, facing, true, true, true)
    shoot_fx:set_elevation(16*2)
    user:get_field():spawn(shoot_fx, user:get_tile())
    local spell = graphic_init("spell", 10*2, 0, ROUNDSHOT_TEXTURE, ROUNDSHOT_PALETTE, ROUNDSHOT_ANIMPATH, -3, "0", Playback.Loop, user, facing, false, true)
    spell:set_elevation(16*2)
    --Set the hit properties of this spell.
    spell:set_hit_props(
        HitProps.new()
        :dmg(damage)
        :impact()
        :flinch()
        :flash()
        :from(user:get_context())
    )
    local tileWidth = tile:width()/2
    spell.offset_x = spell:get_offset().x
    local x_speed = (tileWidth*2)/speed
    if facing == Direction.Left then x_speed = -x_speed end
    local round = function(val, facing)
        if facing == Direction.Right then
            return math.floor(val)
        else
            return math.ceil(val)
        end
    end
    spell.update_func = function(self, dt)
        self.offset_x = self.offset_x + x_speed
        local round_x = round(self.offset_x, facing)
        if (facing == Direction.Right and round_x >= tileWidth) then
            self.offset_x = (-(tileWidth-(self.offset_x-tileWidth)))
            round_x = round(self.offset_x)
            local tile1 = self:get_tile(Direction.Right,1)
            self:teleport(tile1, ActionOrder.Immediate)
            --print("MOVE RIGHT")
        elseif (facing == Direction.Left and round_x <= -tileWidth) then
            self.offset_x = (tileWidth+(round_x+tileWidth))
            round_x = round(self.offset_x)
            local tile1 = self:get_tile(Direction.Left,1)
            self:teleport(tile1, ActionOrder.Immediate)
            --print("MOVE LEFT")
        end
        --print("x: "..round_x)
        self:set_offset(round_x,0)
        --- Gets the next tile in the specified direction.
        --- If that tile is out of bounds, it returns nil
        local tile = spell:get_tile(facing,1)
        if (tile == nil) then
            -- Spell will be erased once it reaches the end of the field.
            self:delete()
            return
        end
        self:get_tile():highlight(Highlight.Solid)
        --- Attacks the entities this spell collides with.
        self:get_tile():attack_entities(self)
    end
    spell.attack_func = function(self, other, judge)
        if not judge:hint_spawn_gfx() then return end
        local offset_y = math.random(-7,6)
        local offset_x = math.random(-6,5)
        if self:get_facing() == Direction.Left then offset_x = -offset_x end
        local hit_fx = graphic_init("artifact", self:get_offset().x+(offset_x*2), 0, EFFECT_TEXTURE, EFFECT_PALETTE, EFFECT_ANIMPATH, -999, "0", Playback.Once, self, self:get_facing(), true, false, true)
        hit_fx:set_elevation(self:get_elevation()-(offset_y*2))
        self:get_field():spawn(hit_fx, self:get_tile())
    end
    spell.collision_func = function(self, other, judge)
        -- Erases the spell once it hits something
        self:delete()
    end
    spell.battle_end_func = function(self)
        self:delete()
    end
    spell.delete_func = function(self)
        self:erase()
    end
    --- Function that decides whether or not this spell is allowed
    --- to move to a certain tile. This is automatically called for
    --- functions such as slide and teleport.
    --- In this case since it always returns true, it can move over
    --- any tile.
    spell.can_move_to_func = function(tile)
        return true
    end
    user:get_field():spawn(spell, tile)
    return spell
end

-- Checks for non-zero-health Obstacles.
function check_obstacles(tile)
    local ob = tile:find_obstacles(function(o)
        if o:get_animation():has_state("PASS_THROUGH") or o:get_name() == "CANTINTERACT" then
            return false
        else
            return true
        end
        return o:get_health() > 0
    end)
    return #ob > 0 
end

-- Checks for unfriendly Characters.
function check_characters(tile, self)
    local characters = tile:find_characters(function(c)
        return c:get_id() ~= self:get_id() and c:get_team() ~= self:get_team()
    end)
    return #characters > 0
end

-- Checks for any Characters.
function check_characters_true(tile)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0
    end)
    return #characters > 0
end

function check_characters_true_team(tile, self)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0 and c:get_tile():get_team() == self:get_tile():get_team()
    end)
    return #characters > 0
end

return package_init