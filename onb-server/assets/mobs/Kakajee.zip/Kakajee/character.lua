local print_debug = false

local CHARACTER_TEXTURE = Engine.load_texture(_folderpath.."gfx/battle.grayscaled.png")
local CHARACTER_ANIMPATH = _folderpath.."gfx/battle.animation"
local SPARKS_TEXTURE = Engine.load_texture(_folderpath.."gfx/sparks.grayscaled.png")
local SPARKS_ANIMPATH = _folderpath.."gfx/sparks.animation"

local THUNDER1_TEXTURE = Engine.load_texture(_folderpath.."gfx/thunder1.grayscaled.png")
local THUNDER1_ANIMPATH = _folderpath.."gfx/thunder1.animation"
local THUNDER2_TEXTURE = Engine.load_texture(_folderpath.."gfx/thunder2.grayscaled.png")
local THUNDER2_ANIMPATH = _folderpath.."gfx/thunder2.animation"

local RECOVERY_TEXTURE = Engine.load_texture(_folderpath.."gfx/recovery.grayscaled.png")
local RECOVERY_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/recovery.png")
local RECOVERY_ANIMPATH = _folderpath.."gfx/recovery.animation"
local THUNDERBOLT_TEXTURE = Engine.load_texture(_folderpath.."gfx/thunderbolt.grayscaled.png")
local THUNDERBOLT_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/thunderbolt.png")
local THUNDERBOLT_ANIMPATH = _folderpath.."gfx/thunderbolt.animation"

local RECOVERY_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_108.ogg")
local THUNDERBOLT_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_31.ogg")
local DOLLTHUNDER_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_70.ogg")

--possible states for character
local states = { IDLE = 1, WAIT = 2, ATTACK = 3, END = 4 }

function debug_print(str)
    if print_debug then
        print("[Kakajee] "..str)
    end
end

--(Function by Alrysc, edited by K1rbYat1Na)
local function graphic_init(type, x, y, texture, palette, animation, layer, state, anim_playback, user, facing, delete_on_complete, relative_to_user, flip)
    texture = texture or nil
    animation = animation or nil
    layer = layer or nil
    state = state or nil
    anim_playback = anim_playback or nil
    facing = facing or nil
    delete_on_complete = delete_on_complete or false
    flip = flip or false
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(user:get_team())
    end
    if palette then
        graphic:store_base_palette(palette)
        graphic:set_palette(graphic:get_base_palette())
    end
    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then 
        graphic:set_facing(facing)
    end
    
    if relative_to_user and user:get_facing() == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end

local function create_hitbox(user, tile, t1, t2)
    local facing = user:get_facing()
    local field = user:get_field()
    local team = user:get_team()
    local spell = Battle.Spell.new(team)
    spell:set_facing(facing)
    spell:set_hit_props(
        HitProps.new()
        :dmg(user.damage_dollthunder)
        :impact()
        :flinch()
        :flash()
        :elem(Element.Elec)
        :from(user:get_context())
    )
    spell.update_func = function(self)
        if user.state ~= states.ATTACK then
            self:delete()
        else
            tile:attack_entities(self)
        end
    end
    spell.battle_end_func = function(self)
        self:delete()
    end
    spell.delete_func = function(self)
        self:erase()
    end
    field:spawn(spell,tile)
    return spell
end

local function create_dollthunder(user)
    local facing = user:get_facing()
    local field = user:get_field()
    local thunder1_fx = graphic_init("spell", 0, 0, THUNDER1_TEXTURE, user:get_base_palette(), THUNDER1_ANIMPATH, -3, "0", Playback.Loop, user, facing)
    thunder1_fx.update_func = function(self)
        if user.state ~= states.ATTACK then
            self:delete()
        end
    end
    thunder1_fx.battle_end_func = function(self)
        self:delete()
    end
    thunder1_fx.delete_func = function(self)
        self:erase()
    end
    local thunder2_fx = graphic_init("spell", 0, 0, THUNDER2_TEXTURE, user:get_base_palette(), THUNDER2_ANIMPATH, -3, "0", Playback.Loop, user, facing)
    thunder2_fx.update_func = function(self)
        if user.state ~= states.ATTACK then
            self:delete()
        end
    end
    thunder2_fx.battle_end_func = function(self)
        self:delete()
    end
    thunder2_fx.delete_func = function(self)
        self:erase()
    end
    local tile1 = user:get_tile()
    local tile2 = user:get_tile(facing,4)
    local new_x = 0
    local start_x = 1
    if facing == Direction.Right then
        start_x = field:width()
    end
    local tile2_x = tile2:x()
    local tile2_y = tile2:y()
    if not tile2 then
        new_x = tile:width()*(tile2_x-start_x)
        if facing == Direction.Right then
            tile2 = field:tile_at(field:width()+1,tile2_y)
        else
            tile2 = field:tile_at(0,tile2_y)
        end
        thunder2_fx:set_offset(new_x,thunder2_fx:get_offset().y)
    end
    user.thunder1 = thunder1_fx
    field:spawn(user.thunder1,tile1)
    user.thunder2 = thunder2_fx
    field:spawn(user.thunder2,tile2)
    for i=1,field:width() do
        local tile = user:get_tile(facing,i)
        if tile and not tile:is_edge() then
            create_hitbox(user, tile, user.thunder1, user.thunder2)
        end
    end
    Engine.play_audio(DOLLTHUNDER_AUDIO, AudioPriority.Immediate)
end

local function create_thunderbolt(user)
    local facing = user:get_facing()
    local field = user:get_field()
    Engine.play_audio(THUNDERBOLT_AUDIO, AudioPriority.Immediate)
    user:set_health(user:get_max_health())
    local thunder_fx = graphic_init("artifact", user:get_offset().x, user:get_offset().y, THUNDERBOLT_TEXTURE, THUNDERBOLT_PALETTE, THUNDERBOLT_ANIMPATH, -3, "0", Playback.Once, user, facing, true, false, true)
    field:spawn(thunder_fx, user:get_tile())
    return thunder_fx
end

local function create_recovery(user)
    local facing = user:get_facing()
    local field = user:get_field()
    Engine.play_audio(RECOVERY_AUDIO, AudioPriority.Immediate)
    user:set_health(user:get_max_health())
    local heal_fx = graphic_init("artifact", user:get_offset().x, user:get_offset().y, RECOVERY_TEXTURE, RECOVERY_PALETTE, RECOVERY_ANIMPATH, -99, "0", Playback.Once, user, facing, true, false, true)
    field:spawn(heal_fx, user:get_tile())
    return heal_fx
end

function package_init(self, character_info)
    debug_print("package_init called")

    -- Required function, main package information
    self.texture = CHARACTER_TEXTURE
    self.animation = self:get_animation()
    self.animation:load(CHARACTER_ANIMPATH)
    
    -- Load extra resources

    -- Set up character meta
    self:set_name(character_info.name)
    self:set_health(character_info.health)
    self:set_element(character_info.element)
    self:set_texture(self.texture, true)
    self:set_height(66)
    self:set_float_shoe(false)
    self:set_air_shoe(false)
    self:share_tile(false)
    self:set_explosion_behavior(2, 1, false)
    self:set_offset(0,0)
    self:store_base_palette(Engine.load_texture(_folderpath.."gfx/palette/battle-"..self:get_rank()..".png"))
    self:set_palette(self:get_base_palette())

    -- DefenseRules
    self.defense = Battle.DefenseVirusBody.new()
    self:add_defense_rule(self.defense)

    -- Initial state
    self.animation:set_state("PLAYER_IDLE")
    self.animation:set_playback(Playback.Once)
    self.animation:refresh(self:sprite())
    self.started = false
    self.collision_available = true
    self.damage = character_info.damage
    self.damage_dollthunder = character_info.damage_dollthunder
    self.state = 1
    self.frames = 0
    
    self.thunder1 = nil
    self.thunder2 = nil
    
    self.spark_fx = self:create_node()
    self.spark_fx:set_texture(SPARKS_TEXTURE)
    self.spark_fx:set_layer(1)
    self.spark_fx:enable_parent_shader(true)
    self.spark_anim = Engine.Animation.new(SPARKS_ANIMPATH)
    self.spark_anim:set_state("0")
    self.spark_anim:set_playback(Playback.Once)
    self.spark_anim:refresh(self.spark_fx)

    local attacking_interrupt = function()
        if self.state == states.ATTACK then
            self.counterable_component.timer = 0
            self.set_state(states.END)
            self.frames = 0
        end
    end

    local ref = self
    --This is how we animate nodes.
    --[[
    self.animate_component = Battle.Component.new(self, Lifetimes.Battlestep)
    self.animate_component.update_func = function(self, dt)
        ref.spark_anim:update(dt, ref.spark_fx)
        ref.spark_anim:update(dt, ref.spark_fx)
    end
    self:register_component(self.animate_component)]]
    self.counterable_component = Battle.Component.new(self, Lifetimes.Battlestep)
    self.counterable_component.timer = 0
    self.counterable_component.update_func = function(self, dt)
        ref.spark_anim:update(dt, ref.spark_fx)
        ref.spark_anim:update(dt, ref.spark_fx)
        if self.timer > 0 then
            debug_print("COUNTERABLE")
            self.timer = self.timer - 1
            ref:toggle_counter(true)
        elseif self.timer == 0 then
            self.timer = -2
            ref:toggle_counter(false)
        end
    end
    self:register_component(self.counterable_component)

    -- Bring it back next build. For now, relying on the stun callback
    self.on_countered = function(self)
        debug_print("Countered")
        --self.counterable_component.timer = 0
        attacking_interrupt()
    end

    self:register_status_callback(Hit.Drag, attacking_interrupt)
    self.can_move_to_func = function(tile)
        --if self:is_rooted() then return false end
        if tile:is_edge() or not tile:is_walkable() then
            return false
        end
        if(tile:is_reserved({self:get_id()})) then
            return false
        end
        if tile == self:get_tile() then
            return true
        end
        if tile:get_team() ~= self:get_team() then
            return false
        end
        return not check_obstacles(tile) and not check_characters_true(tile)
    end
    
    self.on_spawn_func = function(self)
        debug_print("on_spawn_func called")
        if character_info.name_on_spawn then
            self:set_name(character_info.name)
        end
    end
    self.battle_start_func = function(self)
        debug_print("on_battle_start_func called")
        self.spark_fx:set_offset(0,-32)
    end
    self.battle_end_func = function(self)
        debug_print("battle_end_func called")
    end
    self.delete_func = function(self) 
        debug_print("delete_func called")
    end
    self.counter_heal = false
    self.defense_rule = Battle.DefenseRule.new(0, DefenseOrder.Always)
    self.defense_rule.filter_statuses_func = function(props)
        if props.damage > 0 and props:has_element(Element.Elec) then
		    props.flags = props.flags & ~Hit.Stun
            props.damage = 0
        end
		return props
	end
    self.defense_rule.can_block_func = function(judge, attacker, defender)
        local props = attacker:copy_hit_props()
        if props.damage > 0 and props:has_element(Element.Elec) then
            if self.state == states.IDLE then
                self.counter_heal = true
                self.set_state(states.WAIT)
            end
            create_recovery(self)
        end
        judge:hint_spawn_gfx(true)
    end
    self:add_defense_rule(self.defense_rule)
    self.action_idle = function(frame,dt)
        for i=121,180 do
            if frame == i then
                self:get_tile():highlight(Highlight.Flash)
            end
        end
        if frame == 1 then
            self.animation:set_state("PLAYER_IDLE")
            self.animation:refresh(self:sprite())
        end
        if frame == 181 then
            self.set_state(states.WAIT)
        end
    end
    self.action_wait = function(frame,dt)
        if frame == 1 then
            if not self.counter_heal then
                create_recovery(self)
            else
                self.counter_heal = false
            end
        end
        if frame == 2 then
            self.animation:set_state("ATTACK_START")
            self.animation:set_playback(Playback.Loop)
            self.animation:refresh(self:sprite())
            self.spark_anim:set_state("EFFECT1")
            self.spark_anim:set_playback(Playback.Loop)
            self.spark_anim:refresh(self.spark_fx)
            create_thunderbolt(self)
        end
        for i=44,60 do
            if frame == i then
                self:get_tile():highlight(Highlight.Flash)
            end
        end
        if frame == 61 then
            self.counterable_component.timer = 30 -- Makes the Character counter-able for 30f.
            self.set_state(states.ATTACK)
        end
    end
    self.action_attack = function(frame,dt)
        if frame == 1 then
            self.animation:set_state("ATTACKING")
            self.animation:set_playback(Playback.Loop)
            self.animation:refresh(self:sprite())
            self.spark_anim:set_state("EFFECT2")
            self.spark_anim:set_playback(Playback.Once)
            self.spark_anim:refresh(self.spark_fx)
            create_dollthunder(self)
        end
        if frame == 123 then
            self.set_state(states.END)
        end
    end
    self.action_end = function(frame,dt)
        if frame == 1 then
            self.animation:set_state("ATTACK_END")
            self.animation:refresh(self:sprite())
        end
        if frame == 15 then
            self.set_state(states.IDLE)
        end
    end
    local actions = { [1] = self.action_idle, [2] = self.action_wait, [3] = self.action_attack, [4] = self.action_end }
    self.set_state = function(state)
        self.state = state
        self.frames = 0
    end
    self.update_func = function(self,dt)
        check_collision(self)
        if not self.started then
            self.started = true
            self.set_state(states.IDLE)
        else
            local on_action_func = actions[self.state]
            on_action_func(self.frames,dt)
        end
        self.frames = self.frames + 1
    end
end

function create_collision_attack(user, tile)
    local spell = Battle.Spell.new(user:get_team())
    spell:set_facing(user:get_facing())
    local hit_props = HitProps.new()
    :dmg(user.damage)
    :impact()
    :flinch()
    :flash()
    :from(user:get_context())
    :elem(user:get_element())
    spell:set_hit_props(hit_props)
    spell.update_func = function(self)
        tile:attack_entities(self)
        self:delete()
    end
    user:get_field():spawn(spell, tile)
end

function check_collision(user)
    local t = user:get_tile()
    if user.collision_available and check_characters(t, user) then 
        create_collision_attack(user, t)
    end
end

-- Checks for non-zero-health Obstacles.
function check_obstacles(tile)
    local ob = tile:find_obstacles(function(o)
        if o:get_animation():has_state("PASS_THROUGH") or o:get_name() == "CANTINTERACT" then
            return false
        else
            return true
        end
        return o:get_health() > 0
    end)
    return #ob > 0 
end

-- Checks for unfriendly Characters.
function check_characters(tile, self)
    local characters = tile:find_characters(function(c)
        return c:get_id() ~= self:get_id() and c:get_team() ~= self:get_team()
    end)
    return #characters > 0
end

-- Checks for any Characters.
function check_characters_true(tile)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0
    end)
    return #characters > 0
end

return package_init