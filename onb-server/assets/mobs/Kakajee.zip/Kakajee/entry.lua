local shared_package_init = include("../Kakajee/character.lua")

function package_init(character)
    local character_info = {
        name = "Kakajee",
        name_on_spawn = true,
        health = 100,
        damage = 80,
        element = Element.Elec,
        damage_dollthunder = 30
    }
    if character:get_rank() == Rank.V2 then
        character_info.name = "Kakadasu"
        character_info.health = 140
        character_info.damage = 120
        character_info.damage_dollthunder = 60
    elseif character:get_rank() == Rank.V3 then
        character_info.name = "Kakadappe"
        character_info.health = 180
        character_info.damage = 180
        character_info.damage_dollthunder = 80
    elseif character:get_rank() == Rank.SP then
        character_info.name_on_spawn = false
        character_info.health = 220
        character_info.damage = 220
        character_info.damage_dollthunder = 100
    elseif character:get_rank() == Rank.Rare1 then
        character_info.name = "RarKakjee"
        character_info.health = 180
        character_info.damage = 180
        character_info.damage_dollthunder = 70
    elseif character:get_rank() == Rank.Rare2 then
        character_info.name = "RrKakjee2"
        character_info.health = 220
        character_info.damage = 250
        character_info.damage_dollthunder = 110
    else
        character_info.name_on_spawn = false
    end
    shared_package_init(character,character_info)
end