local print_debug = false

local CHARACTER_TEXTURE = Engine.load_texture(_folderpath.."gfx/battle.grayscaled.png")
local CHARACTER_ANIMPATH = _folderpath.."gfx/battle.animation"

local WHITEWEB_TEXTURE = Engine.load_texture(_folderpath.."gfx/whiteweb.grayscaled.png")
local WHITEWEB_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/whiteweb.png")
local WHITEWEB_ANIMPATH = _folderpath.."gfx/whiteweb.animation"

local MOB_MOVE_TEXTURE = Engine.load_texture(_folderpath.."gfx/mob_move.grayscaled.png")
local MOB_MOVE_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/mob_move.png")
local MOB_MOVE_ANIMPATH = _folderpath.."gfx/mob_move.animation"
local EFFECT0_TEXTURE = Engine.load_texture(_folderpath.."gfx/effect0.grayscaled.png")
local EFFECT0_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/effect0.png")
local EFFECT0_ANIMPATH = _folderpath.."gfx/effect0.animation"
local EFFECT1_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/effect1.png")
local EFFECT5_TEXTURE = Engine.load_texture(_folderpath.."gfx/effect5.grayscaled.png")
local EFFECT5_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/effect5.png")
local EFFECT5_ANIMPATH = _folderpath.."gfx/effect5.animation"
local BOOM_TEXTURE = Engine.load_texture(_folderpath.."gfx/boom.grayscaled.png")
local BOOM_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/boom.png")
local BOOM_ANIMPATH = _folderpath.."gfx/boom.animation"

local WARP_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE4_259.ogg", true)
local BOOM_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE4_273.ogg", true)
local WHITEWEB_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE4_239.ogg", true)

local ObstacleInfo = include("libs/ObstacleInfo.lua")
local WindPush = include("libs/WindPush.lua")

function debug_print(str)
    if print_debug then
        print("[Kuumoss] "..str)
    end
end

--possible states for character
local states = { IDLE = 1, MOVE_WAIT = 2, MOVING = 3, STUCK = 4 }

--(Function by Alrysc, edited by K1rbYat1Na)
local function graphic_init(type, x, y, texture, palette, animation, layer, state, anim_playback, user, facing, delete_on_complete, relative_to_user, flip)
    texture = texture or nil
    animation = animation or nil
    layer = layer or nil
    state = state or nil
    anim_playback = anim_playback or nil
    facing = facing or nil
    delete_on_complete = delete_on_complete or false
    flip = flip or false
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(user:get_team())
    end
    if palette then
        graphic:store_base_palette(palette)
        graphic:set_palette(graphic:get_base_palette())
    end
    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then 
        graphic:set_facing(facing)
    end
    
    if relative_to_user and user:get_facing() == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end

local function move_slide(self, direction, frames1, frames2)
    self.slide_component = Battle.Component.new(self, Lifetimes.Battlestep)
    local cur_tile = 1
    local self_tile = self:get_tile()
    local tileWidthO = self_tile:width()
    local tileHeightO = self_tile:height()
    local tileWidth = tileWidthO/2
    local tileHeight = tileHeightO/2 - tileHeightO/10
    local offset_x = self:get_offset().x
    local offset_y = self:get_offset().y
    local round = function(val)
        if facing == Direction.Right then
            return math.floor(val)
        else
            return math.ceil(val)
        end
    end
    self.slide_component.update_func = function()
        if self:is_bubbled() then
            self.slide_component:eject()
            self.slide_component = nil
            self:set_offset(0,0)
            return
        end
        if self:is_stunned() or self:is_frozen() or self.is_deleting then return end
        ----
        local frames = frames1
        if self:is_confused() or self:is_blind() then
            frames = frames2
        end
        local round_x = 0
        local round_y = 0
        if direction == Direction.Up then
            offset_y = offset_y - tileHeightO/frames
            round_y = round(offset_y)
            if round_y < 0 and cur_tile == 2 then
                round_y = 0
                cur_tile = 3
            end
            if round_y < -tileHeight and cur_tile == 1 then
                self:teleport(self:get_tile(Direction.Up,1), ActionOrder.Immediate)
                round_y = (tileHeight+(round_y+tileHeight))
                offset_y = round_y
                cur_tile = 2
            end
        elseif direction == Direction.Down then
            offset_y = offset_y + tileHeightO/frames
            round_y = round(offset_y)
            if round_y > 0 and cur_tile == 2 then
                round_y = 0
                cur_tile = 3
            end
            if round_y > tileHeight and cur_tile == 1 then
                self:teleport(self:get_tile(Direction.Down,1), ActionOrder.Immediate)
                round_y = -(tileHeight-(round_y-tileHeight))
                offset_y = round_y
                cur_tile = 2
            end
        elseif direction == Direction.Left then
            offset_x = offset_x - tileWidthO/frames
            round_x = round(offset_x)
            if round_x < 0 and cur_tile == 2 then
                round_x = 0
                cur_tile = 3
            end
            if round_x < -tileWidth and cur_tile == 1 then
                self:teleport(self:get_tile(Direction.Left,1), ActionOrder.Immediate)
                round_x = (tileWidth+(round_x+tileWidth))
                offset_x = round_x
                cur_tile = 2
            end
        elseif direction == Direction.Right then
            offset_x = offset_x + tileWidthO/frames
            round_x = round(offset_x)
            if round_x > 0 and cur_tile == 2 then
                round_x = 0
                cur_tile = 3
            end
            if round_x > tileWidth and cur_tile == 1 then
                self:teleport(self:get_tile(Direction.Right,1), ActionOrder.Immediate)
                round_x = -(tileWidth-(round_x-tileWidth))
                offset_x = round_x
                cur_tile = 2
            end
        end
        self:set_offset(round_x,round_y)
        if cur_tile >= 3 then
            self.slide_component:eject()
            self.slide_component = nil
            self:set_offset(0,0)
        end
    end
    self:register_component(self.slide_component)
end

local function create_white_web(user, facing, damage, tile)
    if not tile or tile:is_edge() then return end
    local function create_collision(user, facing, damage, tile, ref)
        local spell = Battle.Spell.new(user:get_team())
        spell:set_facing(facing)
        spell:set_hit_props(
            HitProps.new()
            :dmg(damage)
            :impact()
            :flinch()
            :elem(Element.Wood)
            :from(user:get_context())
        )
        spell.update_func = function(self)
            tile:attack_entities(self)
            self:delete()
        end
        spell.attack_func = function(self, other, judge)
            if not judge:hint_spawn_gfx() then return end
            local offset_y = math.random(-5,4)
            local offset_x = math.random(-5,4)
            local hit_fx = graphic_init("artifact", (offset_x*2), (offset_y*2), EFFECT5_TEXTURE, EFFECT5_PALETTE, EFFECT5_ANIMPATH, -999, "0", Playback.Once, self, self:get_facing(), true, true, true)
            hit_fx:set_palette(EFFECT1_PALETTE)
            hit_fx:get_animation():on_frame(2,function()
                hit_fx:set_palette(hit_fx:get_base_palette())
            end)
            self:get_field():spawn(hit_fx, self:get_tile())
        end
        spell.collision_func = function(self, other, judge)
            ref:delete()
        end
        ref:get_field():spawn(spell, tile)
        return spell
    end
    Engine.play_audio(WHITEWEB_AUDIO, AudioPriority.Immediate)
    local web = graphic_init("obstacle", 0, 0, WHITEWEB_TEXTURE, WHITEWEB_PALETTE, WHITEWEB_ANIMPATH, -3, "0", Playback.Once, user, facing)
    web.anim = web:get_animation()
	ObstacleInfo.set_cannot_be_targeted(web, true)
	ObstacleInfo.set_cannot_be_manipulated(web, true)
	ObstacleInfo.set_obstacle_damage(web, Element.Wood, damage)
    web:set_name("WhiteWeb")
    web:set_health(1)
    web:set_float_shoe(true)
    web:set_air_shoe(true)
    web:share_tile(true)
    web:toggle_hitbox(true)
    local defense = Battle.DefenseRule.new(0, DefenseOrder.Always)
    defense.filter_statuses_func = function(a_props)
        a_props.flags = a_props.flags & (~Hit.Flash)
        a_props.flags = a_props.flags & (~Hit.Drag)
        return a_props
    end
    --defense.can_block_func = function(judge, attacker, defender)
    --end
    web:add_defense_rule(defense)
    local component = Battle.Component.new(web, Lifetimes.Battlestep)
    component.frames = 1
    component.update_func = function(self)
        if self.frames == 121 then
            web:delete()
        end
        self.frames = self.frames + 1
    end
    web:register_component(component)
    web.update_func = function(self)
        --tile:attack_entities(self)
        if check_characters(tile,self) then
            create_collision(user, facing, damage, tile, self)
        end
        if self.anim:get_state() == "0" then
            self.anim:on_complete(function()
                self.anim:set_state("1")
                self.anim:set_playback(Playback.Loop)
                self.anim:refresh(self:sprite())
            end)
        end
    end
    web.battle_end_func = function(self)
        self:delete()
    end
    web.delete_func = function(self)
        if self:get_health()<=0 then
            Engine.play_audio(BOOM_AUDIO, AudioPriority.Immediate)
            local boom_fx = graphic_init("artifact", 0, 0, BOOM_TEXTURE, BOOM_PALETTE, BOOM_ANIMPATH, -99, "0", Playback.Once, self, self:get_facing(), true, true, true)
            boom_fx:set_elevation(8*2)
            self:get_field():spawn(boom_fx, self:get_tile())
        end
    end
    user:get_field():spawn(web,tile)
    return web
end

local function web_spawner(self)
    local whitewebs = self:get_tile():find_entities(function(e)
        return e:get_name() == "WhiteWeb" and e:get_team() == self:get_team()
    end)
    local kuumosses = self:get_field():find_characters(function(c)
        return c:get_animation():has_state("IS_KUUMOSS")
    end)
    if self.whitewebs>0 and #kuumosses==1 and #whitewebs<=0 then
        create_white_web(self, self.orig_facing, self.damage_whiteweb, self:get_tile())
        self.whitewebs = self.whitewebs - 1
    end
end

local function choose_dir(user, type)
    local data = {}
    if type == 0 then
        local dirs = {}
        for i=0,3 do
            local dir = math.floor(2^i)
            local tile = user:get_tile(dir,1)
            if tile and user.can_move_to_func(tile) then
                table.insert(dirs, math.floor(2^i))
            end
        end
        if #dirs>0 then
            for i=1,#dirs do
                local state = "MOVE_F"
                if dirs[i] == Direction.Down then
                    state = "MOVE_D"
                elseif dirs[i] == Direction.Up then
                    state = "MOVE_U"
                end
                table.insert(data, {dir=dirs[i], state=state})
            end
        else
            return nil
        end
    else
        local dir = user.current_dir
        local enemies = user:get_field():find_characters(function(c)
            return c:get_health()>0 and not c:is_team(user:get_team())
        end)
        if #enemies==0 then
            return nil
        end
        local user_x = user:get_tile():x()
        local user_y = user:get_tile():y()
        local enemy_x = enemies[1]:get_tile():x()
        local enemy_y = enemies[1]:get_tile():y()
        if user_y > enemy_y then
            table.insert(data, {dir=Direction.Up, state="MOVE_U"})
        elseif user_y < enemy_y then
            table.insert(data, {dir=Direction.Down, state="MOVE_D"})
        else
            if user_x > enemy_x then
                table.insert(data, {dir=Direction.Left, state="MOVE_F"})
            elseif user_x < enemy_x then
                table.insert(data, {dir=Direction.Right, state="MOVE_F"})
            else
                return nil
            end
        end
    end
    return data[math.random(1,#data)]
end

function package_init(self, character_info)
    -- Required function, main package information
    self.texture = CHARACTER_TEXTURE
    self.animation = self:get_animation()
    self.animation:load(CHARACTER_ANIMPATH)
    -- Load extra resources
    -- Set up character meta
    -- Common Properties
    self:set_name(character_info.name)
    self:set_health(character_info.health)
    self:set_element(character_info.element)
    self:set_texture(self.texture, true)
    self:set_height(28)
    self:set_float_shoe(true)
    self:set_air_shoe(true)
    self:share_tile(false)
    self:set_explosion_behavior(2, 1, false)
    self:set_offset(0,0)
    self:set_palette(Engine.load_texture(_folderpath.."gfx/palette/battle-"..self:get_rank()..".png"))
    self.damage = character_info.damage
    -- Kuumoss Specific
    self.damage_contact = character_info.damage_contact
    self.damage_whiteweb = character_info.damage_whiteweb
    self.wait_delay_orig = character_info.wait_delay
    self.move_delay = character_info.move_delay
    self.move_speed_v = character_info.move_speed_v
    self.move_speed_h = character_info.move_speed_h
    -- Other Setup
    if self.damage_whiteweb>0 then
        self.whiteweb_timer = 300
        self.whitewebs = 0
    end
    self.collision_available = true
    self.wait_delay = self.wait_delay_orig
    self.warp_frame = -999
    self.stuck_time = -1
    -- entity will spawn with this animation.
    self.animation:set_state("SPAWN")
    --self.animation:refresh(self:sprite())
    self.frame_counter = 0
    self.started = false
    self.is_deleting = false
    -- This defense rule is added to prevent enemy from gaining invincibility after taking damage.
    self.defense = Battle.DefenseVirusBody.new()
    self:add_defense_rule(self.defense)
    -- Can't be Draged.
    self.defense_rule = Battle.DefenseRule.new(0, DefenseOrder.CollisionOnly)
    self.defense_rule.filter_statuses_func = function(statuses)
		if self.state ~= states.IDLE then
		    statuses.flags = statuses.flags & ~Hit.Drag
        end
		return statuses
	end
    self:add_defense_rule(self.defense_rule)

    self.original_tile = nil -- Stores Kuumoss' original tile.
    self.orig_facing = nil -- Stores Kuumoss' original facing.
    self.current_dir = nil -- Stores Kuumoss' current moving direction.
    self.warp_tile = nil
    self.reserving = false
    self.move_counter = 0
    self.cooldown_frames = 0
    self.moved_from_enemy_tile = 0
    self.do_once = true
    self.do_counter_once = true

    local ref = self
    self.counterable_component = Battle.Component.new(self, Lifetimes.Battlestep)
    self.counterable_component.timer = 0
    self.counterable_component.update_func = function(self)
        if self.timer > 0 then
            debug_print("COUNTERABLE")
            self.timer = self.timer - 1
            ref:toggle_counter(true)
        else
            ref:toggle_counter(false)
        end
    end
    self:register_component(self.counterable_component)
    self.hit_func = function(from_stun)
        debug_print("Hit func runs")
        if from_stun then
            --[[
            if self.warp_tile then
                --self:teleport(self.warp_tile, ActionOrder.Immediate)
                self:get_tile():remove_entity_by_id(self:get_id())
                self.warp_tile:add_entity(self)
                self.warp_tile = nil
            end
            ]]
        end
        self.counterable_component.timer = 0
        self:toggle_counter(false)
    end
    self.on_countered = function(self)
        debug_print("Countered")
        self.hit_func(true)
    end
    self:register_status_callback(Hit.Stun, function() self.hit_func(true) end)
    self:register_status_callback(Hit.Freeze, function() self.hit_func(true) end)

    self.slide_component = nil

    -- actions for states
    self.can_move_to_func = function(tile)
        if self:is_rooted() then return false end
        if tile:is_edge() then
            return false
        end
        if tile:is_hole() and not tile:is_edge() then
            return not check_obstacles(tile) and not check_characters_true(tile)
        end
        if self.warp_tile then
            if tile:get_team() ~= self:get_team() then
                return true
            end
            return true
        else
            if self.state == states.IDLE then
                if tile:get_team() ~= self:get_team() then
                    return false
                end
                return not check_obstacles(tile) and not check_characters_true(tile)
            else
                if tile:get_team() ~= self:get_team() then
                    return true
                else
                    if tile:get_team() == self:get_team() and self:get_tile():get_team() == self:get_team() then
                        return true
                    end
                    if self.moved_from_enemy_tile == 0 then
                        return false
                    end
                end
                return true
            end
        end
    end
    -- Code that runs in the default state
    ---@param frame number
    self.action_idle = function(frame)
        if self.reserving then
            self.original_tile:reserve_entity_by_id(self:get_id())
        end
        if frame == 1 then
            debug_print("IDLE")
            self:never_flip(false)
            self:set_facing(self.orig_facing)
            self.animation:set_state("PLAYER_IDLE")
            self.animation:set_playback(Playback.Loop)
            self.reserving = false
            self.do_once = true
            self.warp_tile = nil
            self.warp_frame = -999
        end
        if frame >= self.wait_delay and self.do_once then
            debug_print("SEARCHING")
            local field = self:get_field()
            local enemies = field:find_characters(function(c)
                return c:get_health()>0 and not c:is_team(self:get_team())
            end)
            if #enemies>0 and not self:is_rooted() then
                local field = self:get_field()
                local e_tile_x = enemies[1]:get_tile():x()
                local e_tile_y = enemies[1]:get_tile():y()
                local tile = field:tile_at(e_tile_x,1)
                if e_tile_y == 1 then
                    tile = field:tile_at(e_tile_x,field:height())
                end
                self.warp_tile = tile
                if not self.can_move_to_func(self.warp_tile) and not check_obstacles(tile) and not check_characters_true(tile) then return end -- Waits when the tile isn't occupied.
                self.do_once = false
                self.warp_frame = frame
                Engine.play_audio(WARP_AUDIO, AudioPriority.Immediate)
                self.original_tile = self:get_tile()
                self.orig_facing = self:get_facing()
                self.reserving = true
                self.do_counter_once = true
            end
        end
        if frame == self.warp_frame+1 and not self.do_once and not self:is_rooted() then
            create_mob_move(self, "0", self.original_tile)
        end
        if frame >= self.warp_frame+4 and not self.do_once and not self:is_rooted() then
            create_mob_move(self, "0", self.warp_tile)
            self.wait_delay = self.wait_delay_orig -- Resets the wait delay.
            self:teleport(self.warp_tile, ActionOrder.Immediate)
            self.set_state(states.MOVE_WAIT)
        end
    end

    ---@param frame number
    self.action_move_wait = function(frame)
        if self.reserving then
            self.original_tile:reserve_entity_by_id(self:get_id())
        end
        if frame == 1 then
            --print("MOVE_WAIT")
            web_spawner(self)
            local data = nil
            self.warp_tile = nil
            self.warp_frame = -999
            if not self.do_once then
                self.do_once = true
                if self:get_tile():y() == self:get_field():height() then
                    data = {dir=Direction.Up,state="MOVE_U"}
                else
                    data = {dir=Direction.Down,state="MOVE_D"}
                end
            else
                if check_characters(self:get_tile(), self) then
                    data = choose_dir(self, 0)
                    self.moved_from_enemy_tile = 1
                else
                    data = choose_dir(self, 1)
                    if data == nil then
                        data = choose_dir(self, 0)
                    end
                    self.moved_from_enemy_tile = 0
                end
            end
            if data then
                self.current_dir = data.dir
                if self.current_dir == Direction.Left or self.current_dir == Direction.Right then
                    self:never_flip(false)
                    self:set_facing(self.current_dir)
                else
                    self:never_flip(true)
                    self:set_facing(self.orig_facing)
                end
                self.animation:set_state(data.state)
                self.animation:set_playback(Playback.Loop)
            else
                self.set_state(states.MOVE_WAIT)
                return
            end
        end
        if frame >= self.move_delay then
            -- counterable only when starts moving after teleport to the enemy's field
            if self.do_counter_once then
                self.do_counter_once = false
                self.counterable_component.timer = 10
            end
            self.set_state(states.MOVING)
        end
    end
    self.action_moving = function(frame)
        if self.reserving then
            self.original_tile:reserve_entity_by_id(self:get_id())
        end
        if frame == 1 then
            --print("MOVING")
        end
        if not self.slide_component then
            web_spawner(self)
            if self.moved_from_enemy_tile == 2 then
                self.set_state(states.MOVE_WAIT)
                return
            end
            --print("not sliding")
            local field = self:get_field()
            local tile = self:get_tile(self.current_dir,1)
            local found = false
            if self.moved_from_enemy_tile == 0 and check_characters(self:get_tile(), self) then
                --print("to move_wait 1")
                self.moved_from_enemy_tile = 1
                self.set_state(states.MOVE_WAIT)
                return
            end
            if self.can_move_to_func(tile) then
                -- can move
                -- firstly, checks if there are enemies on sides
                local tile2 = nil
                if self.current_dir == Direction.Left or self.current_dir == Direction.Right then
                    local dir2 = Direction.Up
                    for i=1,field:height() do
                        tile2 = self:get_tile(dir2,i)
                        if check_characters(tile2,self) then
                            found = true
                            break
                        end
                        if tile2:is_edge() then
                            break
                        end
                    end
                    if not found then
                        dir2 = Direction.Down
                        for i=1,field:height() do
                            tile2 = self:get_tile(dir2,i)
                            if check_characters(tile2,self) then
                                found = true
                                break
                            end
                            if tile2:is_edge() then
                                break
                            end
                        end
                    end
                    if not found and not check_obstacles(tile) then
                        if self.moved_from_enemy_tile == 1 then
                            self.moved_from_enemy_tile = 2
                        end
                        move_slide(self, self.current_dir, self.move_speed_h, self.move_speed_h*2)
                    end
                else
                    local dir2 = self:get_facing()
                    for i=1,field:width() do
                        tile2 = self:get_tile(dir2,i)
                        if check_characters(tile2,self) then
                            found = true
                            break
                        end
                        if tile2:is_edge() then
                            break
                        end
                    end
                    if not found then
                        dir2 = self:get_facing_away()
                        for i=1,field:width() do
                            tile2 = self:get_tile(dir2,i)
                            if check_characters(tile2,self) then
                                found = true
                                break
                            end
                            if tile2:is_edge() then
                                break
                            end
                        end
                    end
                    if not found and not check_obstacles(tile) then
                        if self.moved_from_enemy_tile == 1 then
                            self.moved_from_enemy_tile = 2
                        end
                        move_slide(self, self.current_dir, self.move_speed_v, self.move_speed_v*2)
                    end
                end
            end
            if found or not self.can_move_to_func(tile) then
                --print("to move_wait 2")
                self.set_state(states.MOVE_WAIT)
                return
            end
            if check_obstacles(tile) then
                debug_print("STUCK")
                --self.set_state(states.STUCK)
                self.do_stuck()
                return
            else
                self.stuck_time = -1
            end
        end
    end
    self.do_stuck = function()
        if self.stuck_time == -1 then
            debug_print("set stuck timer for "..self:get_id())
            self.stuck_time = 180
        elseif self.stuck_time == 0 then
            self.stuck_time = -1
            self.set_state(states.STUCK)
            return
        end
    end
    self.action_stuck = function(frame)
        if self.reserving then
            self.original_tile:reserve_entity_by_id(self:get_id())
        end
        if frame >= 1 and self.do_once then
            --[[
            if frame == 1 then
                self.do_once = true
                self.warp_tile = nil
                self.warp_frame = -999
            end]]
            self.do_once = false
            self.warp_tile = self:get_tile()
            self.warp_frame = frame
        end
        if frame == self.warp_frame+1 and not self.do_once then
            create_mob_move(self, "0", self.warp_tile)
        end
        if frame >= self.warp_frame+4 and not self.do_once then
            create_mob_move(self, "0", self.original_tile)
            self:teleport(self.original_tile, ActionOrder.Immediate)
            self.set_state(states.IDLE)
        end
    end

    --utility to set the update state, and reset frame counter
    ---@param state number
    self.set_state = function(state)
        self.state = state
        self.frame_counter = 0
    end
    local actions = { [1] = self.action_idle, [2] = self.action_move_wait, [3] = self.action_moving, [4] = self.action_stuck }
    self.on_spawn_func = function(self)
        debug_print("on_spawn_func called")
        if character_info.name_on_spawn then
            self:set_name(character_info.name)
        end
        WindPush.make_entity_immune_to_status(self)
        local kuumosses = self:get_field():find_characters(function(c)
            return c:get_animation():has_state("IS_KUUMOSS")
        end)
        self.wait_delay = self.wait_delay_orig*#kuumosses
    end
    self.delete_func = function()
        self.is_deleting = true
    end
    self.update_func = function()
        self.frame_counter = self.frame_counter + 1
        if not self.started then
            self.started = true
            self.set_state(states.IDLE)
            self.orig_facing = self:get_facing()
            --self.current_dir = self:get_facing()
        else
            local action_func = actions[self.state]
            action_func(self.frame_counter)
            if self.cooldown_frames > 0 then
                self.cooldown_frames = self.cooldown_frames - 1
            end
            if self.stuck_time > 0 then
                --debug_print(self:get_id().." stuck timer: "..self.stuck_time)
                self.stuck_time = self.stuck_time - 1
            end
        end
        -- collision hitbox
        local damage = self.damage_contact
        if self.state == states.IDLE then
            damage = self.damage
            self:share_tile(false)
        else
            if self.whiteweb_timer > 0 then
                self.whiteweb_timer = self.whiteweb_timer - 1
            else
                self.whiteweb_timer = 300
                self.whitewebs = 2
            end
            self:share_tile(true)
        end
        check_collision(self, damage)
    end
end

function create_mob_move(user, state, tile)
    local move_fx = graphic_init("artifact", 0, 0, MOB_MOVE_TEXTURE, MOB_MOVE_PALETTE, MOB_MOVE_ANIMPATH, -99, state, Playback.Once, user, user:get_facing(), true, true, true)
    move_fx:set_elevation(8*2)
    user:get_field():spawn(move_fx, tile)
    return move_fx
end

function create_collision_attack(user, damage, tile)
    local spell = Battle.Spell.new(user:get_team())
    spell:set_facing(user:get_facing())
    spell:set_hit_props(
        HitProps.new()
        :dmg(damage)
        :impact()
        :flinch()
        :flash()
        :breaking()
        :from(user:get_context())
        :elem(user:get_element())
    )
    spell.update_func = function(self)
        tile:attack_entities(self)
        self:delete()
    end
    spell.attack_func = function(self, other, judge)
        if not judge:hint_spawn_gfx() then return end
        local offset_y = math.random(-6,5)
        local offset_x = math.random(-7,5)
        if self:get_facing() == Direction.Left then offset_x = -offset_x end
        local hit_fx = graphic_init("artifact", self:get_offset().x+(offset_x*2), self:get_offset().y+(offset_y*2), EFFECT0_TEXTURE, EFFECT0_PALETTE, EFFECT0_ANIMPATH, -999, "0", Playback.Once, self, self:get_facing(), true, false, true)
        self:get_field():spawn(hit_fx, self:get_tile())
    end
    user:get_field():spawn(spell, tile)
    return spell
end

function check_collision(user, damage)
    local t = user:get_tile()
    if user.collision_available and check_characters(t, user) then 
        create_collision_attack(user, damage, t)
    end
end

-- Checks for non-zero-health Obstacles.
function check_obstacles(tile)
    local ob = tile:find_obstacles(function(o)
        if o:get_animation():has_state("PASS_THROUGH") or o:get_name() == "CANTINTERACT" then
            return false
        else
            return true
        end
        return o:get_health() > 0
    end)
    return #ob > 0 
end

-- Checks for unfriendly Characters.
function check_characters(tile, self)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0 and c:get_id() ~= self:get_id() and c:get_team() ~= self:get_team()
    end)
    return #characters > 0
end

-- Checks for any Characters.
function check_characters_true(tile)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0
    end)
    return #characters > 0
end

function check_characters_true_team(tile, self)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0 and c:get_tile():get_team() == self:get_tile():get_team()
    end)
    return #characters > 0
end

return package_init