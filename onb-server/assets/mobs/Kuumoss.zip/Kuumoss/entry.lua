local shared_package_init = include("../Kuumoss/character.lua")

function package_init(character)
    local character_info = {
        name = "Kuumoss",
        name_on_spawn = true,
        health = 80,
        damage = 40,
        element = Element.Wood,
        damage_contact = 40,
        damage_whiteweb = 0,
        wait_delay = 60,
        move_delay = 20,
        move_speed_v = 20,
        move_speed_h = 26,
    }
    if character:get_rank() == Rank.V2 then
        character_info.name = "KuumossEX"
        character_info.health = 110
        character_info.damage = 70
        character_info.damage_contact = 70
        character_info.damage_whiteweb = 70
        character_info.move_delay = 20
        character_info.move_speed_v = 18
        character_info.move_speed_h = 24
    elseif character:get_rank() == Rank.V3 then
        character_info.name = "Kumomort"
        character_info.health = 140
        character_info.damage = 100
        character_info.damage_contact = 100
        character_info.damage_whiteweb = 100
        character_info.move_delay = 16
        character_info.move_speed_v = 16
        character_info.move_speed_h = 22
    elseif character:get_rank() == Rank.SP then
        character_info.name = "KumomrtEX"
        character_info.health = 180
        character_info.damage = 130
        character_info.damage_contact = 130
        character_info.damage_whiteweb = 130
        character_info.move_delay = 16
        character_info.move_speed_v = 14
        character_info.move_speed_h = 20
    elseif character:get_rank() == Rank.Rare1 then
        character_info.name = "Kumogeits"
        character_info.health = 220
        character_info.damage = 160
        character_info.damage_contact = 160
        character_info.damage_whiteweb = 160
        character_info.move_delay = 12
        character_info.move_speed_v = 12
        character_info.move_speed_h = 18
    elseif character:get_rank() == Rank.Rare2 then
        character_info.name = "KumogtsEX"
        character_info.health = 260
        character_info.damage = 200
        character_info.damage_contact = 200
        character_info.damage_whiteweb = 200
        character_info.move_delay = 12
        character_info.move_speed_v = 10
        character_info.move_speed_h = 16
    else
        character_info.name_on_spawn = false
    end
    shared_package_init(character,character_info)
end