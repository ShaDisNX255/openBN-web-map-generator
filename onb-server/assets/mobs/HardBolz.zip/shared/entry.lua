local AUDIO_DAMAGE = Engine.load_audio(_folderpath.."EXE4_270.ogg")
local AUDIO_DAMAGE_OBS = Engine.load_audio(_folderpath.."EXE4_221.ogg")
local TESTDOT_TEXTURE = Engine.load_texture(_folderpath.."testdot.png")
local TESTDOT_ANIMPATH = _folderpath.."testdot.animation"

local CHARACTER_TEXTURE = Engine.load_texture(_folderpath.."battle.grayscaled.png")
local CHARACTER_ANIMPATH = _folderpath.."battle.animation"
local attachment_texture = Engine.load_texture(_folderpath.."attachment.png")
local attachment_animation_path = _folderpath.."attachment.animation"
local shoot_sfx = Engine.load_audio(_folderpath.."EXE4_241.ogg")
local shadow_texture = Engine.load_texture(_folderpath.."shadow.png")
local shadow_animation_path = _folderpath.."shadow.animation"
local smoke_texture = Engine.load_texture(_folderpath.."smoke.png")
local smoke_animation_path = _folderpath.."smoke.animation"
local AUDIO_CRACK = Engine.load_audio(_folderpath.."EXE4_353.ogg")
local AUDIO_KOORIHOUGAN = Engine.load_audio(_folderpath.."EXE3_11.ogg")
local AUDIO_YOUGANHOUGAN = Engine.load_audio(_folderpath.."EXE3_105.ogg")
local AUDIO_POISONHOUGAN = Engine.load_audio(_folderpath.."EXE4_344.ogg")

local GUARD_TEXTURE = Engine.load_texture(_folderpath.."guard_hit.png")
local GUARD_ANIMPATH = _folderpath.."guard_hit.animation"
local GUARD_AUDIO = Engine.load_audio(_folderpath.."EXE4_49.ogg", true)

--possible states for character
local states = { IDLE = 1, BEGIN_OPEN = 2, OPEN = 3, SHOOT = 4, CLOSE = 5 }
-- Load character resources
local hardHeadCount = -1

---@param self Entity
function package_init(self, character_info)
    -- Required function, main package information

    local base_animation_path = CHARACTER_ANIMPATH
    self:set_texture(CHARACTER_TEXTURE)
    self.animation = self:get_animation()
    self.animation:load(base_animation_path)
    self.animation:set_playback_speed(1)
    -- Load extra resources
    -- Set up character meta
    self:set_name(character_info.name)
    self:set_health(character_info.hp)
    self:set_height(38)
    self:share_tile(false)
    self:set_explosion_behavior(3, 1, false)
    self:set_offset(0, 0)
    self:set_element(character_info.element)
    self.damage = character_info.damage
    self.type = character_info.type
    --different attacks per enemy type set here!
    self:set_palette(Engine.load_texture(character_info.palette))
    self.animation:set_state("IDLE")
    self.frame_counter = 0
    self.frames_between_actions = character_info.frames_between_actions
    self.started = false

    self.move_direction = Direction.Right
    --[[
    self.defense = Battle.DefenseVirusBody.new()
    self:add_defense_rule(self.defense)
    ]]
    self.defense_rule = Battle.DefenseRule.new(0, DefenseOrder.Always)
    self.defense_rule.can_block_func = function(judge, attacker, defender)
        local attacker_hit_props = attacker:copy_hit_props()

        if (self.state == nil or self.state == states.IDLE or self.state == states.BEGIN_OPEN) then

            if attacker_hit_props.flags & Hit.Breaking == Hit.Breaking then
                --cant block breaking hits
                return
            end
            judge:block_impact()
            judge:block_damage()
            Engine.play_audio(GUARD_AUDIO, AudioPriority.Low)
            create_effect(self:get_facing(), GUARD_TEXTURE, GUARD_ANIMPATH, "DEFAULT", math.random(-20,20), math.random(-20,20), true, -999999, self:get_field(), self:get_current_tile())
        end
    end
    self:add_defense_rule(self.defense_rule)

    -- actions for states
    self.action_idle = function(frame)
        if (frame == self.frames_between_actions) then
            self.set_state(states.BEGIN_OPEN)
        end
    end
    ---hardHead shoot
    ---@param frame number
    self.action_beginopen = function(frame)
        if (frame == 1) then
            self.animation:set_state("OPENING")
            self.animation:set_playback(Playback.Loop)
        elseif (frame == 56 or self:get_rank() == Rank.NM) then
            self.set_state(states.OPEN)
        end
    end

    ---hardHead open
    ---@param frame number
    self.action_open = function(frame)
        if (frame == 1) then
            self.animation:set_state("OPEN")
        elseif (frame == 28) then
            self.set_state(states.SHOOT)
        end
    end

    ---hardHead open
    ---@param frame number
    self.action_shoot = function(frame)
        if (frame == 1) then
            self.animation:set_state("SHOOT")
            self.animation:on_frame(2, function()
                Engine.play_audio(shoot_sfx, AudioPriority.Highest)
                local target_tiles = find_tiles(self)
                for index, value in pairs(target_tiles) do
                    local facing = self:get_facing()
                    local field = self:get_field()
                    toss_spell(self,70,attachment_texture,attachment_animation_path,value,40,function()
                        if value:is_walkable() then
                            create_effect(facing, smoke_texture, smoke_animation_path, "1", 0.0, -((3.0)*2), true, -999999, field, value)
                            if      self.type == 2 then
                                Engine.play_audio(AUDIO_KOORIHOUGAN, AudioPriority.Low)
                            elseif  self.type == 3 then
                                Engine.play_audio(AUDIO_YOUGANHOUGAN, AudioPriority.Low)
                            elseif  self.type == 4 then
                                Engine.play_audio(AUDIO_POISONHOUGAN, AudioPriority.Low)
                            else
                                Engine.play_audio(AUDIO_CRACK, AudioPriority.Low)
                            end
                        else
                            create_effect(facing, smoke_texture, smoke_animation_path, "0", 0.0, -((3.0)*2), true, -999999, field, value)
                        end
                    end)
                    toss_spell_shadow(self, 70, 40, value)
                    toss_spell_hitbox(self, 70, 40, value)
                end
            end)
        elseif (frame == 90) then
            self.set_state(states.CLOSE)
        end
    end

    ---hardHead close
    ---@param frame number
    self.action_close = function(frame)
        if (frame == 1) then
            self.animation:set_state("CLOSE")
            self.animation:on_complete(function()
                self.animation:set_state("IDLE")
                self.set_state(states.IDLE)
            end)
        end
    end
    self.on_spawn_func = function(self)
        hardHeadCount = hardHeadCount + 1
        self.start_delay = hardHeadCount * 90
        -- accounts for escape button presses
        -- to avoid delays on later battles
        if (hardHeadCount > 4) then
            hardHeadCount = -1
        end
    end

    --utility to set the update state, and reset frame counter
    ---@param state number
    self.set_state = function(state)
        self.state = state
        self.frame_counter = 0
    end

    local actions = { [1] = self.action_idle, [2] = self.action_beginopen, [3] = self.action_open,
        [4] = self.action_shoot, [5] = self.action_close }

    self.update_func = function()
        self.frame_counter = self.frame_counter + 1
        if not self.started then
            if self.frame_counter > self.start_delay then
                self.current_direction = self:get_facing()
                self.enemy_dir = self:get_facing()
                self.started = true
                self.set_state(states.IDLE)
            end
        else
            local action_func = actions[self.state]
            action_func(self.frame_counter)
        end
    end

    function find_tiles(self)
        local target_char = find_target(self)
        if (not target_char) then
            return {}
        end
        local target_tile = target_char:get_tile()
        local tilePatterns = {}
        local team = self:get_team()
        local enemy_field = getEnemyField(team, target_tile, self:get_field())
        shuffle(enemy_field)
        --targets will always contain the target tile, plus extras.
        table.insert(tilePatterns, target_tile)
        return tilePatterns
    end

    --get the enemy field, besides the target tile.
    function getEnemyField(team, target_tile, field)
        local tile_arr = {}
        for i = 1, 6, 1 do
            for j = 1, 3, 1 do
                local tile = field:tile_at(i, j)
                if (tile ~= target_tile and tile:get_team() ~= team) then
                    table.insert(tile_arr, tile)
                end
            end
        end
        return tile_arr
    end

    --find a target character
    function find_target(self)
        local field = self:get_field()
        local team = self:get_team()
        local target_list = field:find_characters(function(other_character)
            return other_character:get_team() ~= team
        end)
        if #target_list == 0 then
            return
        end
        local target_character = target_list[1]
        return target_character
    end

    function tiletostring(tile)
        return "Tile: ["..tostring(tile:x())..","..tostring(tile:y()).."]"
    end

    --shuffle function to provide some randomness
    function shuffle(tbl)
        for i = #tbl, 2, -1 do
            local j = math.random(i)
            tbl[i], tbl[j] = tbl[j], tbl[i]
        end
        return tbl
    end
end

function toss_spell(tosser,toss_height,texture,animation_path,target_tile,frames_in_air,arrival_callback)
    local starting_height = -60
    local start_tile = tosser:get_current_tile()
    local field = tosser:get_field()
    local spell = Battle.Spell.new(tosser:get_team())
    local spell_animation = spell:get_animation()
    spell_animation:load(animation_path)
    spell_animation:set_state("HOUGAN")
    if      tosser.type == 2 then
        spell_animation:set_state("KOORI")
    elseif  tosser.type == 3 then
        spell_animation:set_state("YOUGAN")
    elseif  tosser.type == 4 then
        spell_animation:set_state("POISON")
    end
    --[[
    if tosser:get_height() > 1 then
        starting_height = -(tosser:get_height()*2)
    end
    ]]

    spell.jump_started = false
    spell.starting_y_offset = starting_height
    spell.starting_x_offset = 10
    if tosser:get_facing() == Direction.Left then
        spell.starting_x_offset = -10
    end
    spell.y_offset = spell.starting_y_offset
    spell.x_offset = spell.starting_x_offset
    local sprite = spell:sprite()
    sprite:set_texture(texture)
    spell:set_offset(spell.x_offset,spell.y_offset)

    spell.update_func = function(self)
        if not spell.jump_started then
            self:jump(target_tile, toss_height, frames(frames_in_air), frames(frames_in_air), ActionOrder.Voluntary)
            self.jump_started = true
        end
        if self.y_offset < 0 then
            self.y_offset = self.y_offset + math.abs(self.starting_y_offset/frames_in_air)
            self.x_offset = self.x_offset - math.abs(self.starting_x_offset/frames_in_air)
            self:set_offset(self.x_offset,self.y_offset)
        else
            arrival_callback()
            self:delete()
        end
    end
    spell.can_move_to_func = function(tile)
        return true
    end
    field:spawn(spell, start_tile)
end

function toss_spell_shadow(tosser, toss_height, frames_in_air, target_tile)
    local starting_height = -60
    local start_tile = tosser:get_current_tile()
    local field = tosser:get_field()
    local spell = Battle.Spell.new(tosser:get_team())
    local spell_animation = spell:get_animation()
    spell_animation:load(shadow_animation_path)
    spell_animation:set_state("0")
    --[[
    if tosser:get_height() > 1 then
        starting_height = -(tosser:get_height())
    end
    ]]

    spell.slide_started = false

    spell.jump_started = false
    spell.starting_y_offset = starting_height
    spell.starting_x_offset = 10
    if tosser:get_facing() == Direction.Left then
        spell.starting_x_offset = -10
    end
    spell.y_offset = spell.starting_y_offset
    spell.x_offset = spell.starting_x_offset
    local sprite = spell:sprite()
    sprite:set_texture(shadow_texture)
    spell:set_offset(spell.x_offset,0)

    spell.update_func = function(self)
        if not spell.jump_started then
            self:jump(target_tile, 0, frames(frames_in_air), frames(frames_in_air), ActionOrder.Voluntary)
            self.jump_started = true
        end
        if self.y_offset < 0 then
            self.y_offset = self.y_offset + math.abs(self.starting_y_offset/frames_in_air)
            self.x_offset = self.x_offset - math.abs(self.starting_x_offset/frames_in_air)
            self:set_offset(self.x_offset,0)
        else
            self:delete()
        end
    end
    spell.can_move_to_func = function(tile)
        return true
    end
    field:spawn(spell, start_tile)
end

function toss_spell_hitbox(tosser, toss_height, frames_in_air, target_tile)
    local starting_height = -60
    local start_tile = tosser:get_current_tile()
    local field = tosser:get_field()
    local spell = Battle.Spell.new(tosser:get_team())
    spell:set_hit_props(
        HitProps.new(
            tosser.damage,
            Hit.Impact | Hit.Flinch | Hit.Flash | Hit.Breaking,
            Element.None,
            tosser:get_id(),
            Drag.None
        )
    )
    spell.attacking = false
    local spell_animation = spell:get_animation()
    spell_animation:load(TESTDOT_ANIMPATH)
    spell_animation:set_state("0")
    spell_animation:set_playback_speed(0)
    local checkHP = function(ent)
        if ent:get_height() > 0 then
            return true
        end
    end
    spell_animation:on_frame(2, function()
        if      tosser.type == 2 then
            target_tile:set_state(TileState.Ice)
        elseif  tosser.type == 3 then
            target_tile:set_state(TileState.Lava)
        elseif  tosser.type == 4 then
            target_tile:set_state(TileState.Poison)
        else
            if #target_tile:find_characters(checkHP) > 0 or #target_tile:find_obstacles(checkHP) > 0 then
                target_tile:set_state(TileState.Cracked)
            else
                target_tile:set_state(TileState.Broken)
            end
        end
    end)
    spell_animation:on_complete(function()
		spell:erase()
	end)
    --[[
    if tosser:get_height() > 1 then
        starting_height = -(tosser:get_height())
    end
    ]]

    spell.slide_started = false

    spell.jump_started = false
    spell.starting_y_offset = starting_height
    spell.starting_x_offset = 10
    if tosser:get_facing() == Direction.Left then
        spell.starting_x_offset = -10
    end
    spell.y_offset = spell.starting_y_offset
    spell.x_offset = spell.starting_x_offset
    local sprite = spell:sprite()
    sprite:set_texture(shadow_texture)
    sprite:hide()
    spell:set_offset(spell.x_offset,spell.y_offset)

    spell.update_func = function(self)
        if self.attacking then
            self:get_current_tile():attack_entities(self)
        end
        if not spell.jump_started then
            self:jump(target_tile, 0, frames(frames_in_air), frames(frames_in_air), ActionOrder.Voluntary)
            self.jump_started = true
        end
        if self.y_offset < 0 then
            self.y_offset = self.y_offset + math.abs(self.starting_y_offset/frames_in_air)
            self.x_offset = self.x_offset - math.abs(self.starting_x_offset/frames_in_air)
            self:set_offset(self.x_offset,self.y_offset)
        else
            spell_animation:set_playback_speed(1)
            self.attacking = true
            --self:delete()
        end
        if not target_tile:is_walkable() then
            self:erase()
        end
    end
    spell.attack_func = function(self, ent)
        if Battle.Obstacle.from(ent) == nil then
            --[[
            if Battle.Player.from(tosser) ~= nil then
                Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Low)
            end
            ]]
        else
            Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
        end
    end
    spell.can_move_to_func = function(tile)
        return true
    end
    field:spawn(spell, start_tile)
end

function create_effect(effect_facing, effect_texture, effect_animpath, effect_state, offset_x, offset_y, flip, offset_layer, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(effect_facing)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    hitfx:never_flip(flip)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(offset_layer)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end

return package_init