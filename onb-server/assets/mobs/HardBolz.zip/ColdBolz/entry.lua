local shared_package_init = include("../shared/entry.lua")

function package_init(character)
    local character_info = {
        name = "ColdBolz",
        hp = 140,
        damage = 100,
        palette = _folderpath.."palette.png",
        frames_between_actions = 110,
        element = Element.Aqua,
        type = 2,
    }
    shared_package_init(character, character_info)
end
