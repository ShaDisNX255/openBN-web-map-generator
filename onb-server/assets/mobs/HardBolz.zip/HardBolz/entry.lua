local shared_package_init = include("../shared/entry.lua")

function package_init(character)
    local character_info = {
        name = "HardBolz",
        hp = 80,
        damage = 80,
        palette = _folderpath.."V1.png",
        frames_between_actions = 200,
        element = Element.None,
        type = 1,
    }
    if character:get_rank() == Rank.SP then
        character_info.hp = 250
        character_info.damage = 150
        character_info.palette = _folderpath.."SP.png"
    end
    shared_package_init(character, character_info)
end
