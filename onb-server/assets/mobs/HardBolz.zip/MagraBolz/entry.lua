local shared_package_init = include("../shared/entry.lua")

function package_init(character)
    local character_info = {
        name = "MagraBolz",
        hp = 200,
        damage = 100,
        palette = _folderpath.."palette.png",
        frames_between_actions = 86,
        element = Element.Fire,
        type = 3,
    }
    shared_package_init(character, character_info)
end
